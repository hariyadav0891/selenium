package TestBase;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeTest;

public class TestBase {

	private static final Logger log = Logger.getLogger(TestBase.class.getName());

	
	@BeforeTest
	public void loadlog4J(){
		String log4jConfPath = System.getProperty("user.dir")+"/log4J.properties";
		PropertyConfigurator.configure(log4jConfPath);
	}
	
	
	
}
