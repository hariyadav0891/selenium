package demo.boeing.test;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import TestBase.TestBase;

public class login_ie  extends TestBase{

	private static final Logger log = Logger.getLogger(login_ie.class.getName());
	WebDriver driver;
	
	@BeforeClass
	public void browserLunch(){
		
		System.setProperty("webdriver.ie.driver", "E:\\testing\\lib\\Drivers\\IEDriverServer_Win32_3.12.0\\IEDriverServer.exe");
		driver= new InternetExplorerDriver();
		log.info("browser started");
		driver.get("https://www.google.com/");
		log.info("Url Launch	");
	}
	@Test
	public void test1(){
		System.out.println(driver.getTitle());
		log.info("Home Page title ");
}
	@Test
	public void test2(){
		driver.findElement(By.xpath("//input[@id='lst-iba']")).sendKeys("Automation");
		//System.out.println(driver.getTitle());
		log.info("Automation enter ");

		
		
	}

	@AfterClass
	public void tierdown(){
		driver.quit();
		log.info("browser Closed");

	}
}
