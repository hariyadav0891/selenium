package mouse_Hover;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class hover {

	public static void main(String[] args) {

        WebDriver driver= new FirefoxDriver();
        driver.manage().window().maximize();
     driver.get("http://seleniumpractise.blogspot.in/2016/08/how-to-perform-mouse-hover-in-selenium.html");

    WebElement ele = driver.findElement(By.xpath("//button[@class='dropbtn']"));
        Actions act= new Actions(driver);
        act.moveToElement(ele).perform();
        
        
      List<WebElement> link=  driver.findElements(By.xpath("//div[@class='dropdown-content']//a"));
        
      int Total_count= link.size();
      
      System.out.println("total Count is :"+Total_count);
      
      for(WebElement eles:link){
    	  
    	  System.out.println("element are :"+eles.getText());
      }
	}

}
