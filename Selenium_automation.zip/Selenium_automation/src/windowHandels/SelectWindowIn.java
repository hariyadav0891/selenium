package windowHandels;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
 
public class SelectWindowIn {
	
	WebDriver driver;
	
	@Test
	
	public void selectWindowhandel() throws Exception{
		driver = new FirefoxDriver();
		driver.get("https://www.hdfc.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(5000);
		driver.findElement(By.xpath(".//*[@id='block-hdfc-site-banner-hdfc-header-banner']/div[2]/div/ul/li[2]/a")).click();
		
		Set<String> all_window = driver.getWindowHandles();
		Iterator<String> itr = all_window.iterator();
		
		String parentwendow=itr.next();
		
		String childwindow=itr.next();
		
		driver.switchTo().window(childwindow);
		
		driver.findElement(By.xpath(".//*[@id='LoginForm1']/input[5]")).click();
		
		//driver.switchTo().alert().accept();
		
		driver.close();
		
		Thread.sleep(5000);
		
		driver.switchTo().window(parentwendow);
		
		driver.findElement(By.xpath("//table[@class='body_text2 three_tabs']/tbody/tr[2]")).isDisplayed();
		
		
		
	}

}
