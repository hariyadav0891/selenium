package seleniumRC;

import com.thoughtworks.selenium.DefaultSelenium;

public class Google_Search {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
          DefaultSelenium selenium=new DefaultSelenium
         ("localhost", 4444, "*firefox", "http://google.com");
          
          selenium.start();
          selenium.open("/");
          selenium.windowMaximize();
          
          selenium.type("lst-ib", "selenium");
          selenium.click("_fZl");
          selenium.click("link=Selenium - Web Browser Automation");
	}

}
