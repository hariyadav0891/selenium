package seleniumRC;

import com.thoughtworks.selenium.DefaultSelenium;

public class GoogleLanguage {
	
	public DefaultSelenium selenium=new DefaultSelenium
			("localhost", 4444, "*firefox", "http://google.com");
	
	public void OpenURL(){
		selenium.start();
		selenium.open("/");
		selenium.windowMaximize();
	} 
public void Hindi() throws Exception {
	selenium.click("//*[@id='_eEe']/a[1]"); //clicking on hindi
	Thread.sleep(3000);
	selenium.click("link=English");	
	Thread.sleep(3000);
	}
public void bangali() throws Exception{
	selenium.click("//*[@id='_eEe']/a[2]");
	Thread.sleep(3000);
	selenium.click("link=English");	
	Thread.sleep(3000);
}
public void Telagu() throws Exception{
	selenium.click("//*[@id='_eEe']/a[3]");
	Thread.sleep(3000);
	selenium.click("link=English");	
	Thread.sleep(3000);
}
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
    
		GoogleLanguage obj=new GoogleLanguage();
		obj.OpenURL();
		obj.Hindi();
		obj.bangali();
		obj.Telagu();
	}

}
