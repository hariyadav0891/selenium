package seleniumRC;

import com.thoughtworks.selenium.DefaultSelenium;

public class Gmail_login_logout {

	public DefaultSelenium selenium=new DefaultSelenium
			("localhost", 4444, "*firefox", "http://gmail.com");
	public void openURL(){
		selenium.start();
		selenium.open("/");
		selenium.windowMaximize();
	}
	public void verifyLogin() throws Exception{
		selenium.type("Email", "harry080891");
		selenium.click("next");
		Thread.sleep(30000);
		selenium.type("Passwd", "sonamyadav27jan");
		
		selenium.click("signIn");
		Thread.sleep(30000);
		
	}
	public void verifyLogout(){
		selenium.click("//*[@id='gb']/div[1]/div[1]/div[2]/div[4]/div[1]/a/span");
		selenium.click("gb_71");
	}
	public static void main(String[] args) throws Exception {
		
		Gmail_login_logout  obj=new Gmail_login_logout();
		obj.openURL();
		obj.verifyLogin();
		obj.verifyLogout();
		
		

	}

}
