package seleniumRC;

import com.thoughtworks.selenium.DefaultSelenium;

public class GmailLogin {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
      DefaultSelenium selenium=new DefaultSelenium
    ("localhost", 4444, "*firefox", "http://gmail.com");
    
      selenium.start();
      selenium.open("/");
      selenium.windowMaximize();
      
      selenium.type("Email", "harry080891");
      selenium.click("next");
      Thread.sleep(3000);
      selenium.type("Passwd", "sonamyadav27jan");
     Thread.sleep(3000);
      selenium.click("signIn");
      //selenium.click("css=span.gb_9a gbii");
     // selenium.click("gb_71");
	}

}
