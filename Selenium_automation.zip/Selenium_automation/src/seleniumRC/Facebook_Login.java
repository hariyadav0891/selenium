package seleniumRC;

import com.thoughtworks.selenium.DefaultSelenium;

public class Facebook_Login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
       DefaultSelenium selenium=new DefaultSelenium
    ("localhost", 4444, "*firefox", "http://facebook.com");
    	
       selenium.start(); //Lunching the browser
       selenium.open("/"); //open url
       selenium.windowMaximize();
       
       selenium.type("email", "8342106946");
       selenium.type("pass", "8800863321");
       selenium.click("u_0_q");
	}
 
}
