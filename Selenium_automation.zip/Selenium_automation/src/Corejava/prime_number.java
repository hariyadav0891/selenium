package Corejava;

import java.util.Scanner;

public class prime_number {

	public static void main(String[] args) {
		int i,count=0;
		Scanner sc =new Scanner(System.in); 
		
		System.out.println("Enter No for Prime check");
		int n=sc.nextInt();
		
		for(i=2; i<=n/2; i++){
			if(n%i==0){
				System.out.println("Number is not Prime No");
				count=1;
				break;
			}
			
		}
 
		if(count==0){
			System.out.println("Number is  Prime ");
		}
		sc.close();
	}

}
