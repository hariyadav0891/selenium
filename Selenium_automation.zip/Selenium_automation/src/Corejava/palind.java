package Corejava;

import org.testng.annotations.Test;

public class palind {
  @Test
  public void f() {
	  String str ,reverse="";
	  
	  str="madam";
	 System.out.println(str.length());
	 
	 for(int i=str.length()-1;i>=0;i--){
		 reverse=reverse+str.charAt(i); 
		 
	 }
	 System.out.print(reverse);
	 if(str.equals(reverse))
		 System.out.println(" It is a Pallandrome");
	 else
		 System.out.println(" It is not  a Pallandrome");
  }


}
