package Corejava;

import java.util.Scanner;

public class Odd_number {

	public static void main(String[] args) {
	Scanner sc= new Scanner(System.in);

	System.out.println("Enter no for Odd Number");
	
	int n=sc.nextInt();
	for(int i=1 ;i<=n; i+=2){
		System.out.println("Odd Numver are "+i);
	}
	sc.close();
	}

}
