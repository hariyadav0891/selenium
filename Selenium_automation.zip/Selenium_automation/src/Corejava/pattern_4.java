package Corejava;

public class pattern_4 {
	public static void main(String [ ]agrs){
		
		for(int i=1 ;i<=5 ;i++){
			for (int j=1 ;j<=i; j++){
				
				System.out.print(" * ");
			}
			System.out.println();
		}
	}
	

}
