package Corejava;

public class Sample {

	public String str="Hari"; //Globle 
	public void test (){
		//String str; //Local 
		//str="hari";
		System.out.println("Hi Welcome to Selenium");
		System.out.println(str);
	}
	
	public void test1 (){
		System.out.println(str);
		test();
	}
	public static void main(String[] args) {

		Sample obj=new Sample();
		obj.test();
		obj.test1();
	}

}
