package Corejava;

import java.util.Scanner;

public class print_integer {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of Integer");
		int n=sc.nextInt();
		for(int i=1 ; i<=n; i++){
			System.out.println("integer No is :- "+i);
		}
		sc.close();
	}


}
