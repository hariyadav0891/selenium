package Corejava;

import org.testng.annotations.Test;

public class SplitString {
  @Test
  public void f() {
	  String str;
	  str="one,three,two,four,six,five";
	  String[] s= str.split(",");
	  System.out.println(s.length);
	  for (int i=0;i<s.length; i++){
		  if(s[i].equalsIgnoreCase("three"))
			  System.out.println(s[i]); 
		  
	  }
  }
}
