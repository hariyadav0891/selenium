package Sikuli;

import org.openqa.selenium.WebDriver;

public class DesktopApplication {
	public WebDriver driver;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
