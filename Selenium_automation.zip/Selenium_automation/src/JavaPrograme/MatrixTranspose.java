package JavaPrograme;

import java.util.Scanner;

public class MatrixTranspose {

	public static void main(String[] args) {

		int i, j, m, n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Matrix for Transpose");
		m=sc.nextInt();
		n=sc.nextInt();
		
		int matrix[][]= new int[m][n];
		System.out.println("Enter Element in matrix");
		
		for(i=0; i<m ;i++){
			for(j=0 ; j<n; j++){
				matrix[i][j]=sc.nextInt();
			}
		}
		int transpose[][]=new int[m][n];
		//System.out.println();
		
		for(i=0 ;i<m ;i++){
			for(j=0 ;j<n; j++){
				transpose[j][i]=matrix[i][j];
			}
		}
		
		System.out.println("Transpose of Enter Matrix");
		for(i=0; i<m ;i++){
			for(j=0 ; j<n ; j++)
				System.out.print(transpose[i][j]+"\t");
				System.out.println();
			
		}
		
		
		sc.close();
	}

}
