package JavaPrograme;

import java.util.Scanner;

public class swapingNumberUsingThirdVariable {

	public static void main(String[] args) {

		int a, b, temp;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two number for swaping");

		a = sc.nextInt();
		b = sc.nextInt();
		System.out.println("first Number before swapinh "+a);
		System.out.println("Scond Number before swapinh "+b);

		
		temp=a;
		a=b;
		b=temp;
		System.out.println("After Swaping values are :-");
		System.out.println("After Swaping  first values is :-" +a);
		System.out.println( "After Swaping  Second values is :-" +b);

		sc.close();
	}

}
