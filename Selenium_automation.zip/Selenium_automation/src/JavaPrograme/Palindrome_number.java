package JavaPrograme;

import java.util.Scanner;

public class Palindrome_number {

	public static void main(String[] args) {

		int sum=0 ,temp ,r;
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Number to check for Palindrome ");
		
		int n=sc.nextInt();
		 temp=n;
		 //n=141
		while(n >0){
			
			r=n%10;
			sum=(sum*10)+r;
			n=n/10;
			
			
		}
		if(temp==sum){
			System.out.println("Number "+ temp +" is palindrome ");
		} else{
			System.out.println("Number "+ temp +" is nor a palindrome ");
		}
		sc.close();
	}

}
