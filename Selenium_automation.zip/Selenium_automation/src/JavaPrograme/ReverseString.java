package JavaPrograme;

import java.util.Scanner;

public class ReverseString {

	public static void main(String[] args) {


		String org ,rev="";
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter string for Reverse ");
		org=sc.nextLine();
		 int l=org.length();
		 
		 for(int i=l-1 ;i>=0 ;i--){
			 rev=rev+org.charAt(i);
			
		 }
		 System.out.println("String after Reverse :- "+rev);
		sc.close();
	}

}
