package JavaPrograme;

public class fabonacciSerise_recursion {
	
	static int i, a=0, b=1 , s=0;
	static void fabonacciSerise(int count){
		
		if(count>0){
			
			s=a+b;
			
			a=b;
			b=s;
			 System.out.print(" " +s);
			 
			 fabonacciSerise(count-1);
			 
			
		}
		
	}

	public static void main(String[] args) {
		int count=10;
		System.out.print("Fabonacci Serise is : ");
		System.out.print( a+ " " + b);
		fabonacciSerise(count-2);

	}

}
