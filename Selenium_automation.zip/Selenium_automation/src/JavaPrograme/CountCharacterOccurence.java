package JavaPrograme;

public class CountCharacterOccurence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		 String s = "Java is java again java again";
		 
		 int count=s.length()- s.replace("a", "").length();
		 System.out.println("Number of Occurence of 'a' in "+s+" ="+count);
	}

}
 