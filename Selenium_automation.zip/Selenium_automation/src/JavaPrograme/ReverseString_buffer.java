package JavaPrograme;

import java.util.Scanner;

public class ReverseString_buffer {

	public static void main(String[] args) {

		Scanner sc= new Scanner(System.in);
		System.out.println("Hello I am Hari Shanker yadav");
		String s=sc.nextLine();
		StringBuffer buffer = new StringBuffer(s);
		System.out.println("string after reverse :- " + buffer.reverse());

		sc.close();
	}

}
