package JavaPrograme;

import java.util.Scanner;

public class fabonacciSerise {

	public static void main(String[] args) {
		
		int a=0 , b=1, s=0;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter No of Element to print");
		
		int n=sc.nextInt();
		System.out.print(a+" "+b);
		
		for(int i=2; i<=n; i++){
			s=a+b;
			
			System.out.print(" "+s);
			
			a=b;
			b=s;
			
			sc.close();
		}

	}

}
