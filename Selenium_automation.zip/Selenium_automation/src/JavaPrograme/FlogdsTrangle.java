package JavaPrograme;

import java.util.Scanner;

public class FlogdsTrangle {

	public static void main(String[] args) {

		int num=1;
		int i,j ,n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter no of rows to print in Flogd trangle");
		
		n=sc.nextInt();
		System.out.println("Flogds Trangle is :-");
		for(i=1; i<=n;i++){
			for(j=1 ;j<=i ;j++){
				System.out.print(num+"  ");
				num++;
			}
			System.out.println();
		}
		
		sc.close();
		
	}

}
