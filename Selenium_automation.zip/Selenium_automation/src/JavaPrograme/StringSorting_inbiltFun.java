package JavaPrograme;

import java.util.Arrays;

public class StringSorting_inbiltFun {

	public static void main(String[] args) {
		String org ="wearjhgasd";
		
		char[] chars=org.toCharArray();
		Arrays.sort(chars);
		String sorted=new String(chars);
		System.out.println(sorted);

	}

}
