package JavaPrograme;

import java.util.Scanner;

public class SwapingWithOutThirdVariable {

	public static void main(String[] args) {

		int a, b;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter two number for without swaping");
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("before swaping first number "+a);
		System.out.println("before swaping first number "+b);
		
		a=a+b;  //10+20=30
		b=a-b;   //30-20
		a=a-b;
		System.out.println("after swaping ....");

		System.out.println("after swaping first number "+a);
		System.out.println("after swaping Scened number "+b);
		sc.close();
	}

}
