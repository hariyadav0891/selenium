package JavaPrograme;

public class StringSorting {

	public static void main(String[] args) {

		String org = "qwedsafgmke";
		int i, j=0;
		char temp = 0;
		char[] chars=org.toCharArray();
				
		for(i=0 ; i<chars.length ;i++){
			for(j=0; j<chars.length ; j++){
				
				if(chars[j]>chars[i]){
					temp=chars[i];
					chars[i]=chars[j];
					chars[j]=temp;
				}
			}
			
		}
		for(int k=0; k<chars.length;k++)
		//System.out.println("character after shorting :- "+chars[k]);
		System.out.print(chars[k]+" ");
	}

}
