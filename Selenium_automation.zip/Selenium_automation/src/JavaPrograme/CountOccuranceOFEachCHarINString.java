package JavaPrograme;

import java.util.Arrays;
import java.util.HashMap;

public class CountOccuranceOFEachCHarINString {
	
	 static void characterchount(String inputString){
		 
		 HashMap<Character, Integer> charCountMap= new HashMap<Character, Integer>();
		 char [] strArray= inputString.toCharArray();
		 Arrays.sort(strArray);
		 //String stored=new String(strArray);
		// System.out.println(stored);
		 
		 for(char c : strArray){
			 if(charCountMap.containsKey(c)){
				 charCountMap.put(c, charCountMap.get(c)+1);
				
			 }else{
				 charCountMap.put(c, 1);
			 }
			 
		 }
		 System.out.println(inputString);
		System.out.println(charCountMap);
		
	}

	public static void main(String[] args) {
		characterchount("JAVA J2EE JAVA JSP J2EE");
	}

}
