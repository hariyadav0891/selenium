package JavaPrograme;

public class ArrayAverage {

	public static void main(String[] args) {

		int[] array = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
		int i, sum = 0;

		for(i=0; i<array.length; i++)
			sum=sum+array[i];
		System.out.println(sum);
			float average= (float)sum/(array.length);
			
			System.out.println(average);	
		//System.out.println(array.length);
		
	}

}
