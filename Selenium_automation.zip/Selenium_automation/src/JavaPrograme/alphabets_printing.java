package JavaPrograme;

public class alphabets_printing {

	public static void main(String[] args) {
		
		char ch;
		
		for(ch='A';ch <='Z'; ch++){
			//System.out.println("Alphabets are :- "+ch);
			System.out.print(ch + " ");
		}

	}

}
