package JavaPrograme;

import java.util.Scanner;

public class CountWord {

	public static void main(String[] args) {


		Scanner  sc= new Scanner(System.in);
		System.out.println("Enter String for Word Count");
		
		String s =sc.nextLine();
		String [] wordCount=s.trim().split(" ");
		
		System.out.println("Number for String Count :- " +wordCount.length);
		sc.close();
	}

}
