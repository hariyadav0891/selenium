package JavaPrograme;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {

		int n , r,temp ,a=0;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Number to check for Armstrong ");
		n=sc.nextInt();
		temp=n;
		//n=153
		while(n>0){
			r=n%10;
			n=n/10;
			a=a+(r*r*r);
		}
		
		if(temp==a){
			System.out.println(" Enter number "+temp+" is a Armstrong Number");
		}else{
			System.out.println(" Enter number "+temp+" is not  a Armstrong Number");
		}
		sc.close();
	}

}
