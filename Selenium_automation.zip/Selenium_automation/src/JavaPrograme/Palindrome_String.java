package JavaPrograme;

import java.util.Scanner;

public class Palindrome_String {
	
	public static void main(String[] args) {
		
		String reverse="";
		
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter String to check for Palindrame");
		String s=sc.nextLine();
		
		int l=s.length();
		for(int i=l-1; i>=0;i--){
			
			reverse=reverse+s.charAt(i);	
		}
		
		if(s.equals(reverse)){
			System.out.println("Enter string is palindrome");
		}  else{
			System.out.println("Enter string is  not a palindrome");
		}
		sc.close();	
	}

}
