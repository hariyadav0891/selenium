package JavaPrograme;

import java.util.Scanner;

public class SubString {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter String for Find Out Sub String");
		
		String s1=sc.nextLine();
		//welcome to india
		//0123345789012345
		
		

		System.out.println("Sub String are :- "+s1.substring(9));
		//Sub String are :- o india
		System.out.println("Sub String are :- "+s1.substring( 0 ,11));
		//Sub String are :- welcome to 
		sc.close();
	}

}
