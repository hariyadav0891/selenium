package JavaPrograme;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {


		int  n  ,a ,rev=0;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter a Inter for Reverse ");
		n=sc.nextInt();
	  //1234
		
		while(n > 0){
			
			a=n%10;
			rev=(rev*10)+a;
			n=n/10;
		}
		System.out.println("After Reverse a number is :- "+rev);
		sc.close();
	}

}
