package JavaPrograme;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		
		int count=0;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Number to chack for prime number");
		
		int n=sc.nextInt();
		
		for(int i=1 ; i<n/2; i++){
			if(n%2==0){
				System.out.println("Enter Numver "+n+" is not a prime number");
				count++;
				break;
				
			}
			
		}

		if(count==0){
			System.out.println("enter number " + n+ " is a prime number");
		}
		sc.close();
	}

}
