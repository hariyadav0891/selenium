package JavaPrograme;

import java.util.Scanner;

public class CompareTwoString {

	public static void main(String[] args) {

		String str1, str2;
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter First String for Compair");
		str1 = sc.nextLine();

		System.out.println("Enter Second String for Compair");

		str2 = sc.nextLine();
		if (str1.compareTo(str2) > 0) {
			System.out.println("String First is Greater Then String Second ");

		} else if (str1.compareTo(str2) < 0) {
			System.out.println("String First is Smaller then String Second ");

		} else {
			System.out.println("Both String are same");
		}
		sc.close();
	}

}
