package JavaPrograme;

import java.util.Scanner;

public class FactorialNumber {

	public static void main(String[] args) {

		int i, fact = 1 ,n;
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Number for factorial");
		
		n=sc.nextInt();
		
		for(i=1; i<=n; i++){
			fact=fact*i;
		}

		System.out.println("Factoriel of a number " +n + " is :- "+ fact);
	sc.close();
	}

}
