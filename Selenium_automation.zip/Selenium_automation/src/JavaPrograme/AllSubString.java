package JavaPrograme;

import java.util.Scanner;

public class AllSubString {
	
	public static void main(String[] args){
		
		String org,rev="";
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter String for Find Out Sub String");
		
		org=sc.nextLine();
		int l=org.length();
		for(int c=0; c<l ;c++){
		
			for(int i=1 ; i <=l-c ; i++){
				rev=org.substring(c, c+i);
				System.out.println("Sub String :- " + rev);
			}
		}
		
		
		sc.close();
	}
	
}
