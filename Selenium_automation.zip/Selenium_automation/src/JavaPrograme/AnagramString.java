package JavaPrograme;

import java.util.Arrays;

public class AnagramString {

	static void isAnagram(String s1, String s2){
		//removing all whiteSpace 
		String s3=s1.replaceAll("\\s", "");
		String s4=s2.replaceAll("\\s", "");
		boolean status = true;
		if(s3.length()!=s4.length()){
			status=false;
		}else{
			char [] s1Array=s3.toLowerCase().toCharArray();
			char []s2Array=s4.toLowerCase().toCharArray();
			
			Arrays.sort(s1Array);
			Arrays.sort(s2Array);
			
			status=Arrays.equals(s1Array, s2Array);
		}
		if(status){
			System.out.println(s1+ "and "+ s2 +" are Anagram");
		}else{
			System.out.println(s1+ "and "+ s2 +" are  Not Anagram");

		}
	}
	
	
	
	
	
	
	public static void main(String[] args) {
		 isAnagram("Mother In Law", "Hitler Woman");
		 
	        isAnagram("keEp", "peeK");
	 
	        isAnagram("SiLeNt CAT", "LisTen AcT");
	 
	        isAnagram("Debit Card", "Bad Credit");
	 
	        isAnagram("School MASTER", "The ClassROOM");
	 
	        isAnagram("DORMITORY", "Dirty Room");
	 
	        isAnagram("ASTRONOMERS", "NO MORE STARS");
	 
	        isAnagram("Toss", "Shot");
	 
	        isAnagram("joy", "enjoy");	}

}
