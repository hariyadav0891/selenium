package JavaPrograme;

import java.util.Arrays;

public class ArrayShorting {

	public static void main(String[] args) {


		int[] array1={1789, 2035, 1899, 1456, 2013, 
	            1458, 2458, 1254, 1472, 2365, 
	            1456, 2165, 1457, 2456};
		String [] array2={ "Java", "Python", "PHP",
	            "C#",
	            "C Programming",
	            "C++" };        

		System.out.println("Orginal Numatical Array : "+Arrays.toString(array1));
		Arrays.sort(array1);
		System.out.println("Shorted Numaric Array :"+Arrays.toString(array1));
		
		System.out.println("Orginal String Array : "+Arrays.toString(array2));
		Arrays.sort(array2);
		System.out.println("Shorted string Array :"+Arrays.toString(array2));
		
	}

}
