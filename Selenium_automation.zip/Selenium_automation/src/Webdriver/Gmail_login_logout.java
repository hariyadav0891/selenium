package Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Gmail_login_logout {

	public WebDriver driver;
	
	public void openURL(){
		driver=new FirefoxDriver();
		driver.get("http://gmail.com");
		driver.manage().window().maximize();
	}
	
	public void verifylogin() throws Exception{

		driver.findElement(By.id("Email")).sendKeys("harry080891");
		driver.findElement(By.id("next")).click();
           Thread.sleep(3000);
           driver.findElement(By.id("Passwd")).sendKeys("sonamyadav27jan");
           driver.findElement(By.id("signIn")).click();
           Thread.sleep(25000);
	}
	
	public void verifylogout(){
		driver.findElement(By.xpath("//*[@id='gb']/div[1]/div[1]/div[2]/div[4]/div[1]/a/span")).click();
		driver.findElement(By.id("gb_71")).click();
		
	}
	public static void main(String[] args) throws Exception {
		
		Gmail_login_logout obj=new Gmail_login_logout();
		obj.openURL();
		obj.verifylogin();
		obj.verifylogout();
	}
}
