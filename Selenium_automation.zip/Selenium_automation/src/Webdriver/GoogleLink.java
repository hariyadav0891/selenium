package Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class GoogleLink {
	
	public WebDriver driver;
	
	public void openURL(){
		driver=new FirefoxDriver();
		driver.get("http://google.com");
		driver.manage().window().maximize();
		
	}
	public void clicklinks(String str) throws Exception{
		
		driver.findElement(By.xpath(str)).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='_eEe']/a[1]")).click();
		Thread.sleep(3000);
	}
	
	/*
	public void hindi() throws Exception{
		driver.findElement(By.xpath("//*[@id='_eEe']/a[1]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='_eEe']/a[1]")).click();
		Thread.sleep(3000);
		
	}
	public void bangali() throws Exception{
		driver.findElement(By.xpath("//*[@id='_eEe']/a[2]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='_eEe']/a[1]")).click();
		Thread.sleep(3000);
	}
	
	public void telagu() throws Exception{
		driver.findElement(By.xpath("//*[@id='_eEe']/a[3]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='_eEe']/a[1]")).click();
		Thread.sleep(3000);
	}
	*/
	public static void main(String args[]) throws Exception{
		
		GoogleLink g=new GoogleLink();
		g.openURL();
		g.clicklinks("//*[@id='_eEe']/a[1]");
		g.clicklinks("//*[@id='_eEe']/a[2]");
		g.clicklinks("//*[@id='_eEe']/a[3]");
	
		
	}

}
