package Webdriver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.safari.SafariDriver;

public class AllBrowsers {

	public void ff(){
		WebDriver  driver= new FirefoxDriver();
		driver.get("http://gmail.com");
		driver.manage().window().maximize();
	}
	
	public void opera(){
		WebDriver driver=new OperaDriver();
		driver.get("http://gmail.cpm");
	}
	
	public void safari(){
		WebDriver driver=new SafariDriver();
		driver.get("http://spicejet.com");
	}
	
	public void chrome(){
		System.setProperty("webdriver.chrome.driver", "D:\\testing\\lib\\selenium\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("http://facebook.com");
		driver.manage().window().maximize();
	}
	
	public void ie(){
		System.setProperty("webdriver.ie.driver", "D:\\testing\\lib\\selenium\\IEDriverServer.exe");
	   WebDriver driver=new InternetExplorerDriver();
	   driver.get("http://spicejet.com");
	}
public static void main(String[] args)  {
		
	AllBrowsers obj= new AllBrowsers();
      // obj.ff();	
       //obj.opera();	
      // obj.safari();
       obj.chrome();
       //obj.ie();
	}
}
