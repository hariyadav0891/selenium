package Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class gmail_login_read_logout {

	public WebDriver driver;
	
	public void OpenURL(){
		
		driver=new FirefoxDriver();
		driver.get("http://gmail.com");
		driver.manage().window().maximize();
		
	}
public void VerifyLogin() throws Exception{
	driver.findElement(By.id("Email")).sendKeys("harry080891");
	driver.findElement(By.id("next")).click();
	Thread.sleep(5000);
	driver.findElement(By.id("Passwd")).sendKeys("sonamyadav27jan");
	Thread.sleep(5000);
	driver.findElement(By.id("signIn")).click();
	
	}
public void VerReadmailify(){
	//new Select(driver.findElement(By.id("1x"))).sel 
}
public void verifyLogOut(){
	
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
