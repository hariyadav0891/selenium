package Webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Spicejet_PopUp {
	
	public WebDriver driver;
	
	public void OpenURL(){
		driver=new FirefoxDriver ();
		driver.get("http://spicejet.com");
		driver.manage().window().maximize();
		
	}
 
	public void verifysearch() throws Exception{
		driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1")).click();
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.linkText("Bengaluru (BLR)")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Hyderabad (HYD)")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("20")).click();
		new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult"))).selectByVisibleText("3 Adults");
		new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Child"))).selectByVisibleText("2 Children");
		new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Infant"))).selectByVisibleText("2 Infants");
		new Select(driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"))).selectByVisibleText("Indian Rupee(INR)");
		driver.findElement(By.id("ctl00_mainContent_chk_IndArm")).click();
		driver.findElement(By.id("ctl00_mainContent_btn_FindFlights")).click();
		
		
	}
	public void verifyPopup() throws Exception{
		String str;
		str=driver.getWindowHandle();
		driver.findElement(By.linkText("Currency Converter")).click();
		Thread.sleep(3000);
		driver.switchTo().window("converter");
		new Select(driver.findElement(By.id("CurrencyConverterCurrencyConverterView_DropDownListBaseCurrency"))).selectByVisibleText("UAE Dirham(AED)");
		new Select(driver.findElement(By.id("CurrencyConverterCurrencyConverterView_DropDownListConversionCurrency"))).selectByVisibleText("Indian Rupee(INR)");
		driver.findElement(By.id("CurrencyConverterCurrencyConverterView_TextBoxAmount")).sendKeys("5000");
		driver.findElement(By.id("CurrencyConverterCurrencyConverterView_ButtonConvert")).click();
		driver.findElement(By.id("ButtonCloseWindow")).click();
		driver.switchTo().window(str); 
		new Select(driver.findElement(By.id("AvailabilitySearchInputSelectViewdestinationStation1"))).selectByVisibleText("Chennai (MAA)");
		
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		Spicejet_PopUp s=new Spicejet_PopUp();
		s.OpenURL();
		s.verifysearch();
		s.verifyPopup();
	}

}
