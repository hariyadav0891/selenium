package Webdriver;

import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelAPI {

	public static void main(String[] args) throws IOException {
	FileInputStream fis=new FileInputStream("C:\\Users\\Hari\\Desktop\\selenium\\selenium-15\\pavan.xlsx");
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet s=wb.getSheetAt(0);
	//HSSFSheet sheet1=wb.getSheetAt(0);
	
	String data0 =s.getRow(0).getCell(0).getStringCellValue();
	Double data2=s.getRow(0).getCell(1).getNumericCellValue();
	
	
	System.out.println("Dara From Excel is "+data0);
	System.out.println("Dara From Excel is "+data2);
	wb.close();
	}

}
