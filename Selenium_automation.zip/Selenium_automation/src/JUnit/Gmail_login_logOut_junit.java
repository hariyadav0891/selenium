package JUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Gmail_login_logOut_junit {
	
	public  WebDriver driver;
	

	@Before// precondition
	public void setUp() throws Exception {
		driver=new FirefoxDriver ();
		driver.get("http://gmail.com");
		driver.manage().window().maximize();
	}

	@After   //post condition
	public void tearDown() throws Exception {
		driver.quit();
	}

	@Test  // test scenario
	public void VerifyLogin() throws Exception{
		driver.findElement(By.id("Email")).sendKeys("harry080891");
		driver.findElement(By.id("next")).click();
           Thread.sleep(3000);
           driver.findElement(By.id("Passwd")).sendKeys("sonamyadav27jan");
           driver.findElement(By.id("signIn")).click();
           Thread.sleep(25000);
		
	}
	//@Ignore 
	@Test  // test scenario
	public void VerifyLogOut() {
		driver.findElement(By.xpath("//*[@id='gb']/div[1]/div[1]/div[2]/div[4]/div[1]/a/span")).click();
		driver.findElement(By.id("gb_71")).click();
		
	}

	@Test
	public void test(){
		System.out.println("Welcone to Selenium");
	}
}
