package actiTime;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class handel_Dynamic_table {
	String[] s1={"testing","maintenance","design"};
	@Test
	public void handel_table() throws Exception{

		//String testing="testing";

		int i;
		int j=0;
		//int k=1;

		WebDriver driver= new FirefoxDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.get("https://online.actitime.com/qrs/login.do");


		driver.findElement(By.xpath(".//input[@id='username']")).sendKeys("harry080891");

		driver.findElement(By.xpath(".//*[@id='loginFormContainer']/tbody/tr[1]/td/table/tbody/tr[2]/td/input")).sendKeys("sonamyadav27jan");
		driver.findElement(By.xpath(".//*[@id='loginButton']/div")).click();

		Thread.sleep(3000);
		driver.findElement(By.xpath(".//*[@id='enterTTMainContent']/table[1]/tbody/tr[3]/td[1]/table/tbody/tr/td[7]/nobr/span")).click();

		driver.findElement(By.xpath("//div[@id='createTasksPopup_customerSelector']/table/tbody/tr/td[2]/em/button")).click();

		driver.findElement(By.xpath(".//*[contains(text(),'- New Customer -')]")).click();

		driver.findElement(By.xpath("//*[@id='createTasksPopup_newCustomer']")).sendKeys("Hari Yadav");

		driver.findElement(By.xpath("//*[@id='createTasksPopup_newProject']")).sendKeys("Selenium");

		int count=driver.findElements(By.xpath(".//*[@id='createTasksPopup_createTasksTableContainer']/table/tbody/tr")).size();

		for(i=1; i<=count ;i++){
			String selectdate="10/15/2017";
			Date d= new Date(selectdate);

			SimpleDateFormat dt= new SimpleDateFormat("MM/dd/yyyy");

			String date=dt.format(d);
			System.out.println(date);

			String [] split =date.split("/");

			System.out.println(split[0]+" "+split[1]+" "+split[2]);
			String year= split[2];
			System.out.println("Year -----"+year); 

			String month=split[0];
			System.out.println("month----"+month);

			String day=split[1];
			System.out.println("Day----"+day);

			String xpath1="//*[@id='createTasksPopup_createTasksTableContainer']/table/tbody/tr[";
			String xpath2="]";
			String finalxpath=xpath1+i+xpath2;

			//xpath for enter Task Name 
			String enterTaskName=finalxpath+"/td[1]/input";

			System.out.println("enter Task Name Object :-"+enterTaskName);
			driver.findElement(By.xpath(enterTaskName)).sendKeys("task:-"+i);

			//Xpath for not needed

			String notneeded=finalxpath+"/td[3]/input";

			System.out.println("not Needed :-"+notneeded);
			driver.findElement(By.xpath(notneeded)).sendKeys("I am test");


			//Xpath for select date

			String setDeadLine=finalxpath+"/td[1]/following-sibling::td[3]/child::*/child::table/child::tbody/tr/td[2]";

			System.out.println("Set DeadLine  :-"+setDeadLine);
			driver.findElement(By.xpath(setDeadLine)).click();

			if(i>=1){
				driver.findElements(By.xpath(".//*[@class='x-date-picker x-unselectable atap-base-date-picker atap-date-picker']/table/tbody/tr/td[2]/table/tbody/tr/td[2]/em/button")).get(i-1).click();

			}

			String monthObj =month;
			System.out.println("month Object:-"+monthObj);

			String yearObj= year;
			System.out.println("year Object:-"+yearObj);
			Thread.sleep(2000);

			driver.findElement(By.linkText(monthObj)).click();
			driver.findElement(By.linkText(yearObj)).click(); 

			if(i>=1){
			driver.findElements(By.xpath("//button[@class='x-date-mp-ok']")).get(i-1).click();
			}
			driver.findElement(By.linkText(day)).click();

			// xpath for select type of work
			String typeofWork=finalxpath+"/td[1]/following-sibling::td[4]/div/table/tbody/tr/td[2]";
			System.out.println("type of work:-"+typeofWork);

			driver.findElement(By.xpath(typeofWork)).click();

			Thread.sleep(3000);

			String object="//*[contains(text(),"+"'"+s1[j++]+"'"+")]";	
			System.out.println(object);

			if(i==1){
				int count1=driver.findElements(By.xpath(".//*[@class='x-layer x-menu at-dropdown-list-btn-menu billingTypeSelectorMenu addNewTasks']/ul/li")).size();
				System.out.println("count is:-"+count1);
				WebElement text = driver.findElements(By.xpath(".//*[@class='x-layer x-menu at-dropdown-list-btn-menu billingTypeSelectorMenu addNewTasks']/ul/li")).get(2);

				System.out.println("text :-"+text.getTagName());
				text.click();

			}
			else if(i==2){
				int count1=driver.findElements(By.xpath(".//*[@class='x-layer x-menu at-dropdown-list-btn-menu billingTypeSelectorMenu addNewTasks']/ul/li")).size();
				System.out.println("count is:-"+count1);
				WebElement text = driver.findElements(By.xpath(".//*[@class='x-layer x-menu at-dropdown-list-btn-menu billingTypeSelectorMenu addNewTasks']/ul/li")).get(11);

				System.out.println("text :-"+text.getTagName());
				text.click();

			}
			else if(i==3){
				int count1=driver.findElements(By.xpath(".//*[@class='x-layer x-menu at-dropdown-list-btn-menu billingTypeSelectorMenu addNewTasks']/ul/li")).size();
				System.out.println("count is:-"+count1);
				WebElement text = driver.findElements(By.xpath(".//*[@class='x-layer x-menu at-dropdown-list-btn-menu billingTypeSelectorMenu addNewTasks']/ul/li")).get(21);

				System.out.println("text :-"+text.getTagName());
				text.click();

			}
		}

	}

}
