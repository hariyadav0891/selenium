package interviewQuestion;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class coloreofwebelement {
	
	@Test
	
	public void colorofelementbg(){
		WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		driver.get("http://linkedin.com");
		
	String bgcolor = driver.findElement(By.xpath(".//*[@id='login-submit']")).getCssValue("background-color");
	String color = driver.findElement(By.xpath(".//*[@id='login-submit']")).getCssValue("color");
	System.out.println("background color is : "+bgcolor);
	System.out.println(" color is : "+color);
		driver.quit();
	}
	
}
