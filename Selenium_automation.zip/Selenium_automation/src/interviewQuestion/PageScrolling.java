package interviewQuestion;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class PageScrolling {
	
	WebDriver driver;
	
	@Test
	public void pageScrollinh() throws InterruptedException{
		
		driver= new FirefoxDriver();
		
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,document.body.scrollHeight)");
	 
		Thread.sleep(3000);
	
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-document.body.scrollHeight)");
		
		Thread.sleep(3000);
		
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,500)");
		//((JavascriptExecutor)driver).executeScript("window.scrollBy(0,document.body.scrollLeft)");
		
		Thread.sleep(3000);
		((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-500)");
		
		//((JavascriptExecutor)driver).executeScript("window.scrollBy(0,-document.body.scrollLeft)");
		Thread.sleep(3000);
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);" ,driver.findElement(By.xpath(".//*[@id='homefeatured']/li[4]/div/div[1]/div/a[1]/img")));
	}

}
