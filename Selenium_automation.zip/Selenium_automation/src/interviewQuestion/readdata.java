package interviewQuestion;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class readdata {

	@Test
	
	public void readExcelData() throws Exception{
		
		File fi=new File("C:\\Users\\Hari\\Desktop\\selenium\\TestData.xlsx");
		FileInputStream fis= new FileInputStream(fi);
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet sheet1=wb.getSheetAt(0);
		
		String Data1=sheet1.getRow(1).getCell(0).getStringCellValue();
		System.out.println(Data1);
		String Data2=sheet1.getRow(1).getCell(1).getStringCellValue();
		System.out.println(Data2);
		
		wb.close();
	}
}