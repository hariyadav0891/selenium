package interviewQuestion;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class countRow_column {

	@Test
	public void CountRow_column() throws Exception{
		
		WebDriver driver= new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
		driver.manage().window().maximize();
		
		driver.get("https://erail.in");
		
		driver.findElement(By.xpath("//input[@id='txtStationFrom']")).clear();
		driver.findElement(By.xpath("//input[@id='txtStationFrom']")).sendKeys("New Delhi");
		driver.findElement(By.xpath("//div[contains(text(),'NDLS')]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath(".//input[@id='txtStationTo']")).clear();
		driver.findElement(By.xpath(".//input[@id='txtStationTo']")).sendKeys("Mumbai Central");
	
		driver.findElement(By.xpath("//div[contains(text(),'BCT')]")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(".//input[@id='buttonFromTo']")).click();
		
		
		 List<WebElement> List = driver.findElements(By.xpath(".//*[@id='divTrainsList']/table[1]/tbody/tr[*]/td[1]"));
		int row_count=List.size();
		
		 List<WebElement> list_count = driver.findElements(By.xpath(".//*[@id='divTrainsListHeader']/table/tbody/tr[1]/td[*]"));
		 int column_count=list_count.size();
		System.out.println("Total Roe Count is : "+row_count);
		for(WebElement ele:List){
			System.out.println("List of from station List is :"+ele.getText());
		}
		
		System.out.println("Total Roe Count is : "+column_count);

		for(WebElement ele1:list_count){
			System.out.println("List of from station List is :"+ele1.getText());

		}

	}
}
