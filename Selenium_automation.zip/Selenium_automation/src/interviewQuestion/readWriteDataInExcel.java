package interviewQuestion;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class readWriteDataInExcel {

	@Test
	
	public void readWriteExcelData() throws Exception{
		
		File fi=new File("C:\\Users\\Hari\\Desktop\\selenium\\TestData.xlsx");
		FileInputStream fis= new FileInputStream(fi);
		XSSFWorkbook wb= new XSSFWorkbook(fis);
		XSSFSheet sheet1=wb.getSheetAt(0);
		
		sheet1.getRow(1).createCell(2).setCellValue("pass");
		
		sheet1.getRow(2).createCell(2).setCellValue("fail");
		
		FileOutputStream fout =new FileOutputStream(fi);
		wb.write(fout);
		wb.close();
	}
}
