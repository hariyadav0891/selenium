package interviewQuestion;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class getLocation_cordinate {
	
	@Test
	
	public void getLocation(){
		
        WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
		Point location = driver.findElement(By.id("email")).getLocation();
		
		System.out.println("X Position is : "+location.x);
		System.out.println("Y Position is : "+location.y);
	}

}
