package interviewQuestion;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class inputboxheight {
	
	@Test
	public void inputBoxHeight_width(){
		WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
		Dimension dimesion = driver.findElement(By.id("email")).getSize();
		
		System.out.println("Width is : " +dimesion.width);
		
		System.out.println("Height is  : "+dimesion.height);
	}

}
