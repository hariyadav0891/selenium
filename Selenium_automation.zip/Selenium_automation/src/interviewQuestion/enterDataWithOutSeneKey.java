package interviewQuestion;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class enterDataWithOutSeneKey {

	@Test
	public void enterDataWithOutSeneKeyM() throws Exception{
		
        WebDriver driver= new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
		
		driver.findElement(By.id("email")).sendKeys("harry080891@gmail.com");
		Thread.sleep(5000);
		
		WebElement pass_key = driver.findElement(By.id("pass"));
		JavascriptExecutor js = ((JavascriptExecutor)driver);
		
		js.executeScript("arguments[0].value='sonamyadav27jan'", pass_key);
		
		driver.findElement(By.xpath(".//*[@id='u_0_r']")).click();

		driver.quit();
	}
}
