package testNG_advance;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Dependancy {
	
	@Test
	public void startApp(){
	System.out.println("Starting App");
	Assert.assertEquals(12, 13);
	}

	@Test(dependsOnMethods="startApp")
	public void LoginToAPp(){
		System.out.println("Login in  App");
	}
	@Test(dependsOnMethods="LoginToAPp")
	public void LogOut(){
		System.out.println("Logout App");
		
	}
}
