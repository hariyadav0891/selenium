package testNG_advance;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class VerifyTitle {
	
	WebDriver driver;
	@Test
	public void VerifyApplicationTitle(){
	
		driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://learn-automation.com/");
		
		String mytitle = driver.getTitle();
		System.out.println("title is "+mytitle);
		//String expectedTitle="Selenium WebDriver  - Selenium WebDriver tutorial Step by Step";
		//Assert.assertEquals(mytitle, expectedTitle);
		
		Assert.assertTrue(mytitle.contains("Selenium WebDriver tutorial"));
		System.out.println("test Completed -Page verified");
		
		driver.quit();
	}

	
}
