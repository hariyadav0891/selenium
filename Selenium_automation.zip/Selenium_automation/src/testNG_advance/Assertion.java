package testNG_advance;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Assertion {
	
	
	@Test
	public void test1(){
		 
		Assert.assertEquals(12, 13);
		System.out.println("Test Run");
	}

	@Test
	public void test2(){
		
		
		Assert.assertEquals(12, 13 , "DropDown Count Not MAtrch plase Check");
		System.out.println("Test Run");
	}

}
