package imageComparison;

import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.io.File;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class ImageComparison {
	
	public WebDriver driver;
	
	@BeforeClass
	public void SetUp() throws Exception{
		
		driver=new FirefoxDriver();
		driver.get("http://facebook.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Thread.sleep(10000);
	}
	
	@Test
	public void testImageComparison() throws Exception{
	
	File screenshpot = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	
	FileUtils.copyFile(screenshpot, new File("./screenShot/facebookoutput.png"));
	
	
	File fileInput= new File("./screenShot/facebookInput.png");
	
	File fileOutput= new File("./screenShot/facebookoutput.png");
	
	
	BufferedImage bufferfileInput =ImageIO.read(fileInput);
	DataBuffer bufferfileInput1 = bufferfileInput.getData().getDataBuffer();
	int sizefileinput =bufferfileInput1.getSize();
	System.out.println(sizefileinput);
	
	
	BufferedImage bufferfileOutput = ImageIO.read(fileOutput);	
	DataBuffer bufferfileOutput1 = bufferfileOutput.getData().getDataBuffer();
	int sizefileOutPut = bufferfileOutput1.getSize();
	System.out.println(sizefileOutPut);
	
	Boolean matchlaf= true;
	
	if(sizefileinput == sizefileOutPut){
		Assert.assertTrue(matchlaf, "Image are Same");
	}else{
		matchlaf=false;
		Assert.assertTrue(matchlaf, "Image are Not Same");
	}
	
	}

}
