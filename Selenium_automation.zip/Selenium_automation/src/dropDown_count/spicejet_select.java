package dropDown_count;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class spicejet_select {

	WebDriver driver;

	@Test
	public void spicejet_select_count(){
	    driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://spicejet.com");
		
		WebElement adult=driver.findElement(By.xpath(".//*[@id='ctl00_mainContent_ddl_Adult']"));
	
		Select adult_s=new Select(adult);
		
		List<WebElement> adult_list=adult_s.getOptions();
		int total_adult=adult_list.size();
		System.out.println("total count is---:-"+total_adult);
		
		for(WebElement ele :adult_list){
			System.out.println(" Adult values is ------::-"+ele.getText());
		}
				
		
	
	}
	
	
}
