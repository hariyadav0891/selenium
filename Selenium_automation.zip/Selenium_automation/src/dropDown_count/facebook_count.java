package dropDown_count;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class facebook_count {
	WebDriver driver;

	@BeforeClass
	public void OpenUrl(){
	    driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://facebook.com");
	}
	
	@Test
	public void fb_select(){
			
		WebElement day_dd=driver.findElement(By.xpath("//select[@id='day']"));
		Select day_s=new Select(day_dd);
		
		List <WebElement> day_list=day_s.getOptions();
		
		int day_count=day_list.size();
		
		System.out.println("Total no of day is :"+day_count);
		
		for(WebElement ele:day_list){
			
			System.out.println("day is  ------"+ele.getText());
		}
	}
		
		@Test
		public void fb_select_years(){
				
			WebElement year_yy=driver.findElement(By.xpath("//select[@id='year']"));
			Select year_y=new Select(year_yy);
			
			List <WebElement> year_list=year_y.getOptions();
			
			int year_count=year_list.size();
			
			System.out.println("Total no of Years is :"+year_count);
			
			for(WebElement ele1:year_list){
				
				System.out.println("Year is  ------"+ele1.getText());
			}
		
	}

}
