package dropDown_count;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class gmail_select {
	WebDriver driver;

	@BeforeClass
	public void OpenUrl(){
	    driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://accounts.google.com/SignUp?service=mail&continue=https://mail.google.com/mail/?pc=topnav-about-en");
	}
	
	@Test
	public void gmail_select1(){
		
		driver.findElement(By.xpath(".//*[@id='BirthMonth']/div[1]")).click();
		
		String manth_mm = driver.findElement(By.xpath("//*[@id='BirthMonth']/div[2]")).getText();
		
		System.out.println(manth_mm);

	}

}
