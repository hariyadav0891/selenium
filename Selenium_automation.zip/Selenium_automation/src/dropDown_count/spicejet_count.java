package dropDown_count;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class spicejet_count {

	WebDriver driver;

	@BeforeClass
	public void OpenUrl(){
	    driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("http://spicejet.com");
	}
	
	@Test
	public void spice_select(){
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		
		String flight_from = driver.findElement(By.xpath(".//*[@id='glsctl00_mainContent_ddl_originStation1_CTNR']")).getText();
		
		System.out.println("Flight from ---:-"+flight_from);
	}
	
}	

