package dropDown_count;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class selenium_list {
	
	@Test
	public void list_select(){
		
		WebDriver driver=new FirefoxDriver();
		driver.get("http://seleniumpractise.blogspot.in/2016/08/bootstrap-dropdown-example-for-selenium.html");
		driver.manage().window().maximize();
		
		driver.findElement(By.xpath(".//button[@id='menu1']")).click();
		
    	List<WebElement> total_select = driver.findElements(By.xpath("//ul[@class='dropdown-menu']/li/a"));
    	int total_count=total_select.size();
    	System.out.println("total count is :-"+total_count);
    	
    	for(WebElement ele: total_select){
    		System.out.println("List of values is --------"+ele.getAttribute("innerHTML"));
    	}
    	
    	
	}
	

}
