package Dropdown_selection;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class select_from_dropDown2 {
	
	@Test
	public void  selectDropdown() throws Exception{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://facebook.com");
		
		WebElement month_dropDown= driver.findElement(By.xpath(".//select[@id='month']"));
		 
		Select month_dd=new Select(month_dropDown);
		
        WebElement selected_values= month_dd.getFirstSelectedOption();
		
		System.out.println("Before selection selecter values is  :"+ selected_values.getText());
		
		
		month_dd.selectByIndex(3);
		WebElement selected_values1= month_dd.getFirstSelectedOption();
		
		System.out.println("after selection selecter values is  :"+ selected_values1.getText());
		
	}

}
