package Dropdown_selection;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.Assert;

public class select_from_dropDown3 {
	
	@Test
	public void  selectDropdown() throws Exception{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://facebook.com");
		
		WebElement month_dropDown= driver.findElement(By.xpath(".//select[@id='month']"));
		 
		Select month_dd=new Select(month_dropDown);
		
		List<WebElement> month_list= month_dd.getOptions();
		int totlel_month = month_list.size();
		
		Assert.assertEquals(totlel_month, 13);
		
		System.out.println("Totel Month count is : " +totlel_month);
		
		for (WebElement ele: month_list){
			System.out.println(" Month ase === "+ele.getText());
		}
		
       
	}

}
