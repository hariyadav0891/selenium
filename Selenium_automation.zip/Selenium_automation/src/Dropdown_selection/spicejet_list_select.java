package Dropdown_selection;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class spicejet_list_select {
	
	     @Test
	    public void list_select(){
		
        WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		
		driver.get("http://spicejet.com");
		
		driver.findElement(By.xpath("//input[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		
		WebElement flight_from=driver.findElement(By.xpath("//div[@id='glsctl00_mainContent_ddl_originStation1_CTNR']"));
		
		String flight=flight_from.getText();
		//String[] str=flight.split("/n");
		
		System.out.println(flight);
	}

}
