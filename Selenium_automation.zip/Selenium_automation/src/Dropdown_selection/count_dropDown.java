package Dropdown_selection;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class count_dropDown {
	
	@Test
	public void  selectDropdown() throws Exception{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://spicejet.com");
		
		driver.findElement(By.xpath(".//*[@id='ctl00_mainContent_ddl_originStation1_CTXT']")).click();
		Thread.sleep(3000);
           WebElement leaving_from = driver.findElement(By.xpath("//*[@id='citydropdown']/tbody/tr[2]/td[2]"));
		 
         String flight_from = leaving_from.getText();
         
         System.out.println(flight_from);
		 
		 String[] string=flight_from.split("n/");
		 System.out.println(string.length);
		 
	}

}
