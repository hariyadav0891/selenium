package Dropdown_selection;


import java.util.concurrent.TimeUnit;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class gmail_div_select {
	
	@Test
	public void select_all_option(){
		
		WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		
		driver.get("https://accounts.google.com/SignUp?service=mail&continue=https://mail.google.com/mail/?pc=topnav-about-en");
		
		driver.findElement(By.xpath(".//*[@id='BirthMonth']/div[1]")).click();
		
		 WebElement month_list = driver.findElement(By.xpath("//*[@id='BirthMonth']/div[2]"));
		 
		String month= month_list.getText();
		
		System.out.println(month);
		
	}

}
