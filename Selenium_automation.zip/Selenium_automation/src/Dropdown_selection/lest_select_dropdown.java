package Dropdown_selection;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class lest_select_dropdown {

	@Test
	public void select_dropdown(){
		
		WebDriver driver =new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.get("http://seleniumpractise.blogspot.in/2016/08/bootstrap-dropdown-example-for-selenium.html");
		
		driver.findElement(By.xpath("//button[@id='menu1']")).click();
		
		List<WebElement>menu_dd=driver.findElements(By.xpath("//ul[@class='dropdown-menu']//li/a"));
	    int	count=menu_dd.size();
		System.out.println("total Count is : "+count);
		for(WebElement ele : menu_dd){
			String innerhtml=ele.getAttribute("innerHTML");
			
			System.out.println("values are   :  "+innerhtml);
			
		}
	}
}
