package Dropdown_selection;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class select_from_dropDown {
	
	@Test
	public void  selectDropdown() throws Exception{
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://facebook.com");
		
		
		new Select(driver.findElement(By.xpath(".//select[@id='day']"))).selectByIndex(8);
		Thread.sleep(3000);
		 WebElement Month_dropDown=driver.findElement(By.id("month"));
		 
		 Select Month_dd= new Select(Month_dropDown);
		 
		 Month_dd.selectByValue("8");
		 
		 Thread.sleep(3000);
		 
		 new Select(driver.findElement(By.xpath(".//select[@id='year']"))).selectByVisibleText("1991");
		
		 driver.findElement(By.xpath(".//input[@id='u_0_i']")).click();
		 
	}

}
