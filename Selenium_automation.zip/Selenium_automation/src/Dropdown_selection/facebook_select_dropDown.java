package Dropdown_selection;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class facebook_select_dropDown {
	
	@Test
	public void select_dropdown(){
		
		WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		
		driver.get("http://facebook.com");
		
		WebElement day=driver.findElement(By.xpath(".//select[@id='day']"));
		
		Select day_dd= new Select(day);
		
		List<WebElement> day_list=day_dd.getOptions();
		int total_day=day_list.size();
		
		System.out.println("total count of day's is : " +total_day);
		for(WebElement ele: day_list){
			
			System.out.println("List of lay's is : "+ele.getText());
		}
		
	}

}
