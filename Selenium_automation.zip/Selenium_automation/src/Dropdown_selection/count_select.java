package Dropdown_selection;


import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class count_select {
	
	
	
	@Test
	public void countSelect(){
		
		WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
		driver.get("http://spicejet.com");
		
		WebElement Number_adult=driver.findElement(By.xpath(".//*[@id='ctl00_mainContent_ddl_Adult']"));
		
		 Select audlt_ad = new Select(Number_adult);
		 
		 List<WebElement> adult_list= audlt_ad.getOptions();
		 
		 int total_adult= adult_list.size();
		 System.out.println("toatal no of Adult is : "+total_adult);
		 for(WebElement ele: adult_list){
			 System.out.println("Adult is ----"+ele.getText());
		 }
		 
		 
		
	}

}
