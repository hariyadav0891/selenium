package Dropdown_selection;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class yahoo_select_dropdown {


	@Test
	public void select_dropdown(){
		WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		driver.get("https://login.yahoo.com/account/create?src=fpctx&intl=in&lang=en-IN&done=https%3A%2F%2Fin.yahoo.com&specId=yidReg");
		
		WebElement month=driver.findElement(By.xpath(".//select[@id='usernamereg-month']"));
		
		Select month_select=new Select(month);
		
		List<WebElement> month_list=month_select.getOptions();
		
		int month_count=month_list.size();
		System.out.println("Total no of Month is : " +month_count);
		
		for(WebElement ele: month_list){
			System.out.println("List od month values is : "+ele.getText());
		}
				
		
	}

}
