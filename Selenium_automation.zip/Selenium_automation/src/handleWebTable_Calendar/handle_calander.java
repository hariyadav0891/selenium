package handleWebTable_Calendar;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class handle_calander {
	
	@Test
	public void handle_calander_table() throws Exception{
		
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.redbus.in");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		//driver.findElement(By.id("src")).sendKeys("Bangalore");
		//Thread.sleep(3000);
		//driver.findElement(By.xpath("//div[@class='fl search-box clearfix']/div/input")).click();
		
		//driver.findElement(By.xpath(".//*[@id='dest']")).sendKeys("Hyderabad");
		//Thread.sleep(3000);
		//driver.findElement(By.xpath("//div[@class='fl search-box']/div/input")).click();
		//Thread.sleep(3000);
		
		//driver.findElement(By.xpath("//*[@id='onward_cal']")).click();
		//driver.findElement(By.xpath("//div[@class='fl search-box date-box']/div/input[@id='onward_cal']")).click();
		driver.findElement(By.id("return_cal")).click();
		Thread.sleep(8000);
		
		driver.findElement(By.xpath(".//*[@id='rb-calendar_onward_cal']/table/tbody/tr[7]/td[6]")).click(); 
		
		
		
	}

}
