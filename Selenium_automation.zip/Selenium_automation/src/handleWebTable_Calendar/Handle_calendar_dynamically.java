package handleWebTable_Calendar;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Handle_calendar_dynamically {
	
	@Test
	public void handle_calander_table() throws Exception{
		
		String selectData="12/15/2017";
		Date d=new Date(selectData);
		
		
		SimpleDateFormat dt= new SimpleDateFormat("MMMM/dd/yyyy");
		String date=dt.format(d);
		System.out.println(date);
		
		String [] split=date.split("/");
		String month=split[0]+" "+split[2];
		System.out.println("Month is----- "+month);
		
		WebDriver driver=new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.goibibo.com");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

		driver.findElement(By.xpath(".//*[@id='gi_oneway_label']")).click();
		
		driver.findElement(By.xpath(".//*[@id='searchWidgetCommon']/div/div[3]/div[1]/div[1]/div/input")).click();
		
		Thread.sleep(3000);
		//*[contains(Text(),'November 2017')]
		while(true){
			try{
				//*[contains(text(),'September 2017')]
				driver.findElement(By.xpath("//*[contains(text(),'"+month+"')]")).isDisplayed();				
				String firstpart="//*[@id='fare_";
				String secondpart="']";
				String [] splitDate=selectData.split("/");
				String finalpath=firstpart+splitDate[2]+splitDate[0]+splitDate[1]+secondpart;
				System.out.println("Final Locater is :- "+finalpath);
				driver.findElement(By.xpath(finalpath)).click();
				break;
			}
			catch(Exception e){
				driver.findElement(By.xpath("//div[@class='DayPicker-NavBar']/span")).click();
				Thread.sleep(2000);
			}
		}
	}

}
