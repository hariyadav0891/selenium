package DataDriven;

import java.io.File;
import java.io.IOException;

import org.testng.annotations.Test;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class DataDrivenFramework_1 {

	@Test
	public  void testData() throws  IOException, BiffException {
		File file=new File("C:\\Users\\Hari\\Desktop\\datadriven.xlsx");
		Workbook wb = Workbook.getWorkbook(file);
		Sheet sheet = wb.getSheet(0);
		System.out.println("=====================");
		int row=sheet.getRows();
		int column=sheet.getColumns();
		System.out.println(row);
		System.out.println(column);

	}
}
