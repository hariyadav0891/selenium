package DataDriven;


import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;




public class dataDrivenFramework {
	WebDriver driver;
	
	int rownum;
	
	@BeforeMethod
	public void OpenURl(){
		driver= new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get("https://www.google.com/gmail/about/");
	}
	@Test(dataProvider="gmail")
	public void datadriven(String username ,String password) throws Exception{
		driver.findElement(By.xpath("//a[contains(text(),'Sign In')]")).click();
		Thread.sleep(5000);
		WebElement email = driver.findElement(By.xpath(".//input[@id='identifierId']"));
		email.clear();
		email.sendKeys(username);
		
		driver.findElement(By.xpath(".//*[@id='identifierNext']/content/span")).click();
		Thread.sleep(3000);
		
		WebElement pass= driver.findElement(By.xpath(".//*[@id='password']/div[1]/div/div[1]/input"));
		pass.clear();
		pass.sendKeys(password);
		Thread.sleep(5000);
		
		driver.findElement(By.xpath(".//*[@id='passwordNext']/content")).click();


		System.out.println("Successfull...");
		driver.quit();
	}
	@DataProvider(name="gmail")
	public Object[][] testdatafeed() {
		Object[][] obj= null;
		try {
			File file = new File("C:\\Users\\Hari\\Desktop\\datadriven.xlsx");
			FileInputStream fis = new FileInputStream(file);
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);
			
			int rowCount = sheet.getLastRowNum();
			obj = new Object[rowCount][2];
			for(int i =0 ; i< rowCount; i++){
				Row r=	sheet.getRow(i+1);
				
				obj[i][0] = r.getCell(0).getStringCellValue();
				obj[i][1]  = r.getCell(1).getStringCellValue();		
				
				
			}
				
			
			
			
			
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		// Create 2 D array and pass row and columns
		
		
		return obj;
		
		
	}
@AfterMethod
public void quitbrowser(){
	driver.quit();
}
}
