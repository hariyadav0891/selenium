package DataDriven;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadWriteData {

	@Test
	public void readdata() throws IOException {
		File file = new File("C:\\Users\\Hari\\Desktop\\datadriven.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);
		//String result1 = sheet.getRow(0).getCell(0).getStringCellValue();
		//System.out.println("Data read from data : "+result1);

		int rowCount=sheet.getLastRowNum()-sheet.getFirstRowNum();
		for(int i=0 ;i< rowCount+1;i++){
			XSSFRow row = sheet.getRow(i);
			for(int j=0; j< row.getLastCellNum() ;j++){
				System.out.print(row.getCell(j).getStringCellValue()+" || ");
			}
			System.out.println();
		}
		sheet.getRow(1).createCell(3).setCellValue("Pass");
		sheet.getRow(2).createCell(3).setCellValue("Fail");
		sheet.getRow(3).createCell(3).setCellValue("Sucessfull..");

		FileOutputStream fout = new FileOutputStream(file);
		wb.write(fout);
		System.out.println("Data Updated Successfully ");
		wb.close();

	}

}
