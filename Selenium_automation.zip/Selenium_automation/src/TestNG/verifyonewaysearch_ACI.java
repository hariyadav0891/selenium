package TestNG;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;

public class verifyonewaysearch_ACI {
	public WebDriver driver;
	
	public void verifysearch(String a, String c, String i) throws Exception{
		driver.get("http://spicejet.com");
		driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1")).click();
		driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
		driver.findElement(By.linkText("Bengaluru (BLR)")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("Hyderabad (HYD)")).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("20")).click();
		new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult"))).selectByVisibleText(a);
		new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Child"))).selectByVisibleText(c);
		new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Infant"))).selectByVisibleText(i);
		new Select(driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"))).selectByVisibleText("Indian Rupee(INR)");
		//driver.findElement(By.id("ctl00_mainContent_chk_IndArm")).click();
		driver.findElement(By.id("ctl00_mainContent_btn_FindFlights")).click();
		
		
	}
	
  @Test(description="This test case is to verify one way search with 1 Adult, 0 Children, 0 Infant")
  public void Test01() throws Exception{
	  verifysearch("1 Adult", "0 Children", "0 Infant");
	  
  }
  @Test(description="This test case is to verify one way search with 2 Adult, 1 Children, 0 Infant")
  public void Test02() throws Exception{
	  verifysearch("2 Adults", "1 Child", "0 Infant");
	  
  }
  @Test(description="This test case is to verify one way search with 3 Adult, 2 Children, 1 Infant")
  public void Test03() throws Exception{
	  verifysearch("3 Adults", "2 Children", "1 Infant");
	  
  }
  @BeforeTest
  public void beforeTest() {
	  driver=new FirefoxDriver();
	  driver.manage().window().maximize();
  }

}
