package TestNG;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;

public class ajaxControl {
	public WebDriver driver;
	
  @Test
  public void f() throws Exception{
	  driver.findElement(By.id("lst-ib")).sendKeys("selenium");
	  Thread.sleep(5000);
	 String str= driver.findElement(By.xpath("//*[@id='sbtc']/div[2]/div[2]/div[1]")).getText();
	  System.out.println(str);
	  String [] s=str.split("\n");
	  System.out.println(s.length);
	  for(int i=0; i<s.length;i++){
		  if(s[i].equalsIgnoreCase("selenium Tutorial"))
		  {
			  driver.findElement(By.id("lst-ib")).clear();
			  driver.findElement(By.id("lst-ib")).sendKeys(s[i]);
			  driver.findElement(By.name("btnG")).click();
		  }
	  }
  }
  @BeforeTest
  public void beforeTest() {
	  driver=new FirefoxDriver();
	  driver.get("http://google.com");
	  driver.manage().window().maximize();
	  
  }

}
