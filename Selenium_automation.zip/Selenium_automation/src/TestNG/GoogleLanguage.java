package TestNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;

public class GoogleLanguage {
	public WebDriver driver;
	
	public void clicklinks(String str) throws Exception{
		driver.findElement(By.xpath(str)).click();
		Thread.sleep(3000);
		driver.findElement(By.linkText("English")).click();
		Thread.sleep(3000);
		
	}
  @Test
  public void f() throws Exception {
	  clicklinks("//*[@id='_eEe']/a[1]");
	  clicklinks("//*[@id='_eEe']/a[2]");
	  clicklinks("//*[@id='_eEe']/a[3]");
  }
  @BeforeTest
  public void beforeTest() {
	  driver=new FirefoxDriver();
	  driver.get("http://google.com");
	  driver.manage().window().maximize();
	  
  }

  @AfterTest
  public void afterTest() {
	  driver.quit();
	 
  }

}
