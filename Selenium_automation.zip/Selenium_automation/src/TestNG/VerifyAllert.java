package TestNG;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;

public class VerifyAllert {
	
	public WebDriver driver;
  @Test
  public void f() throws Exception{
	  driver.findElement(By.id("ctl00_mainContent_rbtnl_Trip_1")).click();
	  driver.findElement(By.id("ctl00_mainContent_ddl_originStation1_CTXT")).click();
	  driver.findElement(By.linkText("Bengaluru (BLR)")).click();
	  Thread.sleep(5000);
	  driver.findElement(By.linkText("Hyderabad (HYD)")).click();
	  Thread.sleep(5000);
	  driver.findElement(By.linkText("22")).click();
	  new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Adult"))).selectByVisibleText("9 Adults");
	  new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Child"))).selectByVisibleText("2 Children");
	  new Select(driver.findElement(By.id("ctl00_mainContent_ddl_Infant"))).selectByVisibleText("3 Infants");
	 // driver.findElement(By.id("ctl00_mainContent_chk_StudentDiscount")).click();
	  driver.findElement(By.id("ctl00_mainContent_btn_FindFlights")).click();
	  Thread.sleep(5000);
  }
  @Test
  public void verifyAlert(){
	 String str= driver.switchTo().alert().getText();
	 System.out.println(str);
	  driver.switchTo().alert().accept();  //OK
	  //driver.switchTo().alert().dismiss(); // cancle
  }
  @BeforeTest
  public void beforeTest() {
	  driver=new FirefoxDriver();
	  driver.get("http://spicejet.com");
	  driver.manage().window().maximize();
	  
  }

}
