package screenShot;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import Lib.utility;

public class facebook_screenshot {
	
	@Test
	
	public void fb_screenshot() throws Exception{
		
		WebDriver driver= new FirefoxDriver();
		
		driver.manage().window().maximize();
		
		driver.get("http://facebook.com");
		
		utility.capturescreenshot(driver, "BrowserStarted");
		driver.findElement(By.id("email")).sendKeys("harisyadav0891@gmail.com");
		
		utility.capturescreenshot(driver, "Email is completed");
		
		
		
		
		driver.quit();
	}

	

}
