package Excel_POI;

import Lib.ExceldataConfig;

public class readExcel_data_lib {

	public static void main(String[] args) {
		
		ExceldataConfig excel =new ExceldataConfig("C:\\Users\\Hari\\Desktop\\testdata.xls");
  
		System.out.println(excel.getData(1, 0, 1));
	}

}
