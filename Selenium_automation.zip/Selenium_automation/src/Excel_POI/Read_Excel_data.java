package Excel_POI;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Read_Excel_data {

	public static void main(String[] args) throws Exception {
		File src=new File("C:\\Users\\Hari\\Desktop\\testdata.xls");
		FileInputStream fis=new FileInputStream(src);
		HSSFWorkbook wb= new HSSFWorkbook(fis);
		HSSFSheet sheet1=wb.getSheetAt(0);
		int rowcount=sheet1.getLastRowNum();
		System.out.println("Total No of row Count is "+rowcount);
		
		for(int i=0 ; i<rowcount; i++){
			String data0=sheet1.getRow(i).getCell(0).getStringCellValue();
			System.out.println("Test data From row"+i+" is  "+data0);
		}
		wb.close();
	}
}
