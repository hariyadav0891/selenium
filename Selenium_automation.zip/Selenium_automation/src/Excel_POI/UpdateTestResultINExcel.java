package Excel_POI;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class UpdateTestResultINExcel {

	public static void updateResult(String excellocater, String sheetName, String testCaseName, String testStatus)
			throws IOException {

		FileInputStream file = new FileInputStream(new File(excellocater));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet(sheetName);

		int totalRow = sheet.getLastRowNum() + 1;
		for (int i = 1; i < totalRow; i++) {
			XSSFRow r = sheet.getRow(i);
			String ce = r.getCell(1).getStringCellValue();
			if (ce.contains(testCaseName)) {

				r.createCell(2).setCellValue(testStatus);
				file.close();
				System.out.println("Update Done");
				FileOutputStream outfile = new FileOutputStream(excellocater);
				workbook.write(outfile);
				outfile.close();
				break;
			}
		}
		workbook.close();
	}

	public static void main(String[] args) throws IOException {

		String excellocater=System.getProperty("user.dir")+"/demo.xlsx";
		
		updateResult(excellocater,"TestReport", "Registretion", "Pass");
		updateResult(excellocater,"TestReport", "Payment", "Fali");
		updateResult(excellocater,"TestReport", "Calcletest", "Pass");
		
	}

}
