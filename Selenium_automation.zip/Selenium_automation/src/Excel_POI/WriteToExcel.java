package Excel_POI;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteToExcel {


	public static void main(String[] args) {


		//Blank Work Book
		XSSFWorkbook workbook= new XSSFWorkbook();
		
		// Create blank workbook
		
		XSSFSheet sheet=workbook.createSheet("Test Data");
		
		//need to written 
		
		Map<String , Object[]> data= new TreeMap<String, Object[]>();
		data.put("1", new  Object[]{"ID" , "NAME", "LASTNAME","Lover"});
		data.put("2", new Object[] {1, "Hari" ,"Yadav","Teja"});
		data.put("3", new Object[] {2, "Hari1" ,"Yadav1","Teja1"});
		data.put("4", new Object[] {3, "Hari2" ,"Yadav2","Teja2"});
		data.put("5", new Object[] {4, "Hari3" ,"Yadav3","Teja3"});
		
		
		//Iterate over data
		
		Set<String> keyset =data.keySet();
		int rownum=0;
		
		for(String key:keyset){
			Row row = sheet.createRow(rownum++);
			
			Object[] objArr=data.get(key);
			int cellnum=0;
			for(Object obj:objArr){
				Cell cell = row.createCell(cellnum++);
				if(obj instanceof String){
					cell.setCellValue((String)obj);
				}else if(obj instanceof Integer){
					cell.setCellValue((Integer)obj);
					
				}
				
			}
			try{
				FileOutputStream out= new FileOutputStream(new File("demo.xlsx"));
				workbook.write(out);
				out.close();
				System.out.println("demo>xlsx Written successFully on disk.");
			}
			catch(Exception e){
				e.printStackTrace();
				
			}
			
		}
	
		
	}
	

}
