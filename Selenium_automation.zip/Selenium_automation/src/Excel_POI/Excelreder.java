package Excel_POI;

import java.io.IOException;

public class Excelreder {

	public static void main(String[] args) throws IOException {

		String excellocater=System.getProperty("user.dir")+"/demo.xlsx";
		
		UpdateTestResultINExcel.updateResult(excellocater,"TestReport", "Registretion", "wait");
		UpdateTestResultINExcel.updateResult(excellocater,"TestReport", "Payment", "Fali");
		UpdateTestResultINExcel.updateResult(excellocater,"TestReport", "Calcletest", "Pass");
		
	}

}
