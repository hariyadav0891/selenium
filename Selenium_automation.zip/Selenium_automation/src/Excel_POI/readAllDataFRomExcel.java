package Excel_POI;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readAllDataFRomExcel {

	public static void main(String[] args) {
	
		try{
			FileInputStream file= new FileInputStream( new File("demo.xlsx"));
			XSSFWorkbook workbook= new XSSFWorkbook(file);
			XSSFSheet sheet= workbook.getSheetAt(1);
			Iterator<Row> rowIterater = sheet.iterator();
			while(rowIterater.hasNext()){
				Row row = rowIterater.next();
				
				Iterator<Cell> cellIterater = row.cellIterator();
				while(cellIterater.hasNext()){
					Cell cell = cellIterater.next();
					switch(cell.getCellType()){
					case Cell.CELL_TYPE_NUMERIC:
						System.out.print(cell.getNumericCellValue() + " ");
						break;
					case Cell.CELL_TYPE_STRING :
						System.out.print(cell.getStringCellValue() + " ");
						break;
					
					}
				}
			System.out.println("");
			}
			file.close();
		}catch(Exception e){
			
		}
	
	}

}
