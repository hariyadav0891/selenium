package demo.testNGReport;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(value=PDFReport.class)
public class LoginPageTest extends TestBase{

	
	@Test(priority=1)
	public void loginPageTitleTest(){
		String title = driver.getTitle();
		System.out.println(title);
		
		WebElement textenter = driver.findElement(By.id("lst-ib"));
		textenter.sendKeys("Selenium");
		//textenter.click();
		//driver.findElement(By.xpath("//*[@id='tsf']/div[2]/div[3]/center/input[1]")).click();
		
	}
	
	@Test(priority=2)
	public void loginPageTitleTest2(){
		String title = driver.getTitle();
		System.out.println(title);
		
		WebElement textenter = driver.findElement(By.id("lst-ib"));
		textenter.sendKeys("Selenium");
		textenter.click();
		driver.findElement(By.xpath("//*[@id='tsf']/div[2]/div[3]/center/input[1]")).click();
		
	}
	@Test(priority=3)
	public void loginPageTitleTest3(){
		String title = driver.getTitle();
		System.out.println(title);
		
		WebElement textenter = driver.findElement(By.id("lst-ib"));
		textenter.sendKeys("Selenium");
		textenter.click();
		driver.findElement(By.xpath("//*[@id='tsf']/div[2]/div[3]/center/input[1]")).click();
		
	}
	
	
	
	

}

