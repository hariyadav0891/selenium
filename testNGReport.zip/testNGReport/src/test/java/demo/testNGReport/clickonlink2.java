package demo.testNGReport;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(value=PDFReport.class)
public class clickonlink2 extends TestBase {
	
	@Test(priority=1)
	public void click(){
		
		//driver.findElement(By.xpath("//a[contains(text(),'Introduction — Selenium Documentation')]")).click();
		
	String text2 = driver.getTitle();
	String text1="Google";
		Assert.assertEquals(text2, text1);
	}

	@Test(priority=2)
	public void clickmethod2(){
		
		//driver.findElement(By.xpath("//a[contains(text(),'Introduction — Selenium Documentation')]")).click();
		
	String text2 = driver.getTitle();
	String text1="Google11";
		Assert.assertEquals(text2, text1);
	}
}
