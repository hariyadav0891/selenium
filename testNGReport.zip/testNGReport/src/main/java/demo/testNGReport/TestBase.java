package demo.testNGReport;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;


public class TestBase {
	
	public static WebDriver driver;
	public static Properties prop;
	public  static EventFiringWebDriver e_driver;

	@BeforeSuite
	public static void initialization(){
		
			System.setProperty("webdriver.chrome.driver", "E:\\testing\\lib\\Drivers\\chromedriver_win32\\chromedriver.exe");	
			driver = new ChromeDriver(); 
			
		driver.manage().window().maximize();
		driver.get("https://www.google.com/");
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		
	}
	
	@AfterSuite
	public void browserclose(){
		driver.close();
	}
	
	
	
	
	
	
	
	

}
