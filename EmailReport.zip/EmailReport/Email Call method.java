@AfterSuite
	public void tiredown() {
		driver.close();

		try {
			Runtime.getRuntime().exec(new String[] { "wscript.exe",
					System.getProperty("user.dir") + "/bin/webAppAutomation/Main/Java/EmailReport/SendEmail.vbs" });
			log.info("Email Sended .....");
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}