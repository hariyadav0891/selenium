package bin.webAppAutomation.Main.Java.Util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

//import bin.webAppAutomation.Main.Java.PageHelper.LoginPageHelper;

public class DriverTestCase {
	private static final Logger log = Logger.getLogger(DriverTestCase.class.getName());
	protected static WebDriver driver;
	protected static PropertiesReader data = new PropertiesReader();
	public static ExtentHtmlReporter extentHtmlReporter;
	public static ExtentTest extentTest;
	public static ExtentReports extentReports;

	public DriverTestCase() {
		// BrowserStart();
	}

	public void log(String data) {
		log.info(data);
		Reporter.log(data);
		extentTest.log(Status.INFO, data);
	}

	@BeforeSuite(alwaysRun = true)
	public static void browserStart() {
		log.info("Browser Start");
		System.setProperty("webdriver.ie.driver",
				"C:\\Users\\fw205e\\Downloads\\IEDriverServer_Win32_2.53.1\\IEDriverServer.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		driver = new InternetExplorerDriver(capabilities);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(data.getUrl());
		PageObjectsManager.initialize(driver);

		// =============add Extent report
		extentHtmlReporter = new ExtentHtmlReporter(
				System.getProperty("user.dir") + "/Extend_Report/CMES_Automation_Report_Win_1709.html");
		extentReports = new ExtentReports();
		extentReports.attachReporter(extentHtmlReporter);
		extentReports.setSystemInfo("OS/Version", "Windows-10 Version-1709");
		extentReports.setSystemInfo("Browser", "IE-11.43");

		extentHtmlReporter.config().setDocumentTitle("Windows-10 Version-1709");
		extentHtmlReporter.config().setReportName("Win10/1709-CMES");
		extentHtmlReporter.config().setTheme(Theme.STANDARD);
		extentHtmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		extentHtmlReporter.config().setChartVisibilityOnOpen(false);
		extentHtmlReporter.loadXMLConfig(new File(System.getProperty("user.dir") + "/extent-config.xml"));

	}

	@BeforeClass
	public void beforeClass() {
		extentTest = extentReports.createTest(getClass().getSimpleName());
	}

	@BeforeMethod
	public void beforeMethod(Method result) {
		// extentTest.log(Status.INFO, result.getName() + ":- Started");
	}

	@BeforeTest
	public void loadlog4J() {
		String log4jConfPath = System.getProperty("user.dir") + "/src/Test/Resources/log4J.properties";
		PropertyConfigurator.configure(log4jConfPath);
	}

	@AfterMethod
	public void afterMethod(ITestResult result) throws IOException {
		logReport(result);
	}

	public void logReport(ITestResult result) throws IOException {
		if (result.getStatus() == ITestResult.FAILURE) {
			extentTest.log(Status.FAIL, result.getName() + " Failed");
			// extentTest.log(Status.ERROR, result.getName());
			extentTest.log(Status.ERROR, result.getThrowable());
			extentTest.log(Status.ERROR, "Method Failing:-" + result.getMethod().getMethodName());

			String imagePath = captureScreen(result.getMethod().getMethodName());
			extentTest.fail("Snapshot below: " + extentTest.addScreenCaptureFromPath(imagePath).toString()
					.substring(29, 39).replace("ExtentTest", " "));

		} else if (result.getStatus() == ITestResult.SKIP) {
			extentTest.log(Status.SKIP, result.getName() + " Skipped");
			// extentTest.log(Status.SKIP, result.getThrowable());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			extentTest.log(Status.INFO, result.getName() + " Passed");
		}
	}

	public String captureScreen(String fileName) {
		if (fileName == "") {
			fileName = "blank";
		}
		File destFile = null;
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/screenshot/";
			destFile = new File(reportDirectory + fileName + "_" + formater.format(calendar.getTime()) + ".png");
			FileUtils.copyFile(scrFile, destFile);
			// This will help us to link the screen shot in testNG report
			Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath()
					+ "' height='200' width='200'/> </a>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return destFile.toString();
	}

	@AfterClass
	public void afterClass() {
		extentReports.flush();
	}

	@AfterSuite
	public void tiredown() {
		driver.close();
		/*
		 * try { Runtime.getRuntime().exec(new String[] { "wscript.exe",
		 * System.getProperty("user.dir") +
		 * "/bin/webAppAutomation/Main/Java/EmailReport/SendEmail.vbs" });
		 * log.info("Email Sended ....."); } catch (Exception ex) {
		 * ex.printStackTrace(); }
		 */
	}

}
