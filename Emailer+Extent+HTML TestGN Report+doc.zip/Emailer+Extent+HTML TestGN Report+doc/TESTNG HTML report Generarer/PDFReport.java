package bin.webAppAutomation.Main.Java.ExtentReportListener;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.testng.IReporter;
import org.testng.IResultMap;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.xml.XmlSuite;

public class PDFReport implements IReporter {

	@Override
	public void generateReport(List<XmlSuite> arg0, List<ISuite> arg1, String outputDirectory) {

		StringBuilder finalString = new StringBuilder();
		String secondaryTable = null;
		String primaryTable = null;
		for (ISuite iSuite : arg1) {

			Map<String, ISuiteResult> results = iSuite.getResults();
			// System.out.println("arg1 --------------------------");
			Set<String> keys = results.keySet();

			for (String key : keys) {

				ITestContext context = results.get(key).getTestContext();
				long startTime = context.getStartDate().getTime();
				long endTime = context.getEndDate().getTime();

				long timedifer = Math.round((endTime - startTime) / 1000);
				String totalTimeforexe = Long.toString(timedifer);

				IResultMap resultMapFail = context.getFailedTests();
				IResultMap resultMapPass = context.getPassedTests();
				// System.out.println("Class name : " +
				// resultMapFail.getClass().getName());

				Collection<ITestNGMethod> failedMethods = resultMapFail.getAllMethods();
				Collection<ITestNGMethod> passMethods = resultMapPass.getAllMethods();
				// System.out.println("--------FAILED TEST CASE---------");

				StringBuilder sb = new StringBuilder();
				sb.append("<table cellspacing='0' cellpadding='0' class='result' style='margin-left: 480px; '>")
						.append("<tr>");
				sb.append("<th>").append("Test Case ").append("</th>");
				sb.append("<th>").append("Methods Name").append("</th>");
				// sb.append("<th>").append("Time(ms)").append("</th>");
				sb.append("<th>").append("Status").append("</th>");
				sb.append("</tr>");

				Set<String> totalClass = new HashSet<>();
				Set<String> totalMethod = new HashSet<>();
				int methodFail = 0;
				for (ITestNGMethod iTestNGMethod : failedMethods) {
					methodFail++;
					// Print failed test cases detail

					String className = iTestNGMethod.getTestClass().getRealClass().getSimpleName();
					totalClass.add(className);

					String methodName = iTestNGMethod.getMethodName();
					totalMethod.add(methodName);

					String timeInMs = new Date(iTestNGMethod.getDate()).toString();

					// System.out.println("Fail : className " + className + "
					// methodName " + methodName + " timeInMs " + timeInMs);

					GenerateHtml g = new GenerateHtml();
					String html = g.getRowData(className, methodName, timeInMs, "fail");
					sb.append(html);

				}
				int methodPass = 0;
				for (ITestNGMethod iTestNGMethod : passMethods) {
					methodPass++;
					// Print failed test cases detail
					String className = iTestNGMethod.getTestClass().getRealClass().getSimpleName();
					totalClass.add(className);

					String methodName = iTestNGMethod.getMethodName();
					totalMethod.add(methodName);

					String timeInMs = new Date(iTestNGMethod.getDate()).toString();

					// System.out.println("Pass : className " + className + "
					// methodName " + methodName + " timeInMs " + timeInMs);

					GenerateHtml g = new GenerateHtml();
					String html = g.getRowData(className, methodName, timeInMs, "Pass");
					sb.append(html);

				}

				sb.append("</table>");
				secondaryTable = sb.toString();
				primaryTable = GenerateHtml.getHeaderData(totalClass.size(), totalMethod.size(), passMethods.size(),
						failedMethods.size(), totalTimeforexe);

			}

		}

		finalString.append("<html xmlns='http://www.w3.org/1999/xhtml'>").append(GenerateHtml.getStyel())
				.append("<body>");
		finalString.append(
				"<h2 style='text-align: center ;bgcolor:#3869b5;'>Win 10/1709 CMES Automation Execution - Test Results</h2>");
		finalString.append(primaryTable);
		finalString.append("<h2 style='text-align: center;bgcolor:#3869b5;'>CMES Smoke Suite Test Report</h2>");
		finalString.append(secondaryTable);
		finalString.append("</body>").append("</html>");
		String result = finalString.toString();
		// System.out.println("result " + result);

		// create html file here

		String htmlString = result;
		File newHtmlFile = new File(
				"C:/Users/fw205e/Documents/GIT/BIETC_Win10_Test_Automation/CMES_Automation/Teamsid/bin/webAppAutomation/Main/Java/ExtentReportListener/CMES_Automation_Report_Win_1709.html");
		try {
			FileUtils.writeStringToFile(newHtmlFile, htmlString);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
