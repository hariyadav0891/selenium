package bin.webAppAutomation.Main.Java.ExtentReportListener;

public class GenerateHtml {

	public static String getHeaderData(int totalClass, int totalMethod, int methodPass, int methodFail,
			String totalTime) {

		StringBuilder sb = new StringBuilder();

		sb.append("<table cellspacing='0' cellpadding='0' class='result' style='margin-left: 480px; '>").append("<tr>");
		sb.append("<th>").append("Test").append("</th>");
		sb.append("<th>").append("Total Test Case").append("</th>");
		sb.append("<th>").append("Total Method").append("</th>");
		sb.append("<th>").append("Total Methods Pass").append("</th>");
		sb.append("<th>").append("Total Method Fail").append("</th>");
		sb.append("<th>").append("Total Time Sec.").append("</th>");
		sb.append("</tr>");

		sb.append("<tr>");
		sb.append("<td>").append("Test").append("</td>");
		sb.append("<td>").append(totalClass).append("</td>");
		sb.append("<td>").append(totalMethod).append("</td>");
		sb.append("<td>").append(methodPass).append("</td>");
		sb.append("<td>").append(methodFail).append("</td>");
		sb.append("<td>").append(totalTime).append("</td>");
		sb.append("</tr>");

		sb.append("</table>");

		return sb.toString();
	}

	public String getRowData(String className, String methodName, String timeInMs, String status) {

		StringBuilder sb = new StringBuilder();
		if (status.equalsIgnoreCase("Pass")) {
			sb.append("<tr class='passedodd'>");
		} else {
			sb.append("<tr class='failedeven'>");
		}

		sb.append("<td>");
		sb.append(className);
		sb.append("</td>");

		sb.append("<td>");
		sb.append(methodName);
		sb.append("</td>");

		// sb.append("<td>");
		// sb.append(timeInMs);
		// sb.append("</td>");

		sb.append("<td>");
		sb.append(status);
		sb.append("</td>");

		sb.append("</tr>");

		return sb.toString();
	}

	public static String getStyel() {
		StringBuilder sb = new StringBuilder();

		sb.append("<head> <style type='text/css'>");
		sb.append(
				"table caption, table.info_table, table.result, table.passed, table.failed	{	margin-bottom: 10px;	border: 1px solid #000099;	border-collapse: collapse; empty-cells: show;}");
		sb.append(
				"table.info_table td, table.info_table th, table.result td, table.result th,	table.passed td, table.passed th, table.failed td, table.failed th {	border: 1px solid #000099;	padding: .25em .5em .25em .5em}");

		sb.append("table.result th {	vertical-align: bottom }");

		sb.append("tr.param th { 	padding-left: 1em;	padding-right: 1em}");

		sb.append("tr.param td {	padding-left: .5em;	padding-right: 2em}");

		sb.append("td.numi, th.numi, td.numi_attn {	text-align: right }");

		sb.append("tr.total td { font-weight: bold }");

		sb.append("table caption {	text-align: center; 	font-weight: bold; }");

		sb.append("table.passed tr.stripe td, table tr.passedodd td {	background-color:  #abebc6 ;}");

		sb.append("table.passed td, table tr.passedeven td {	background-color: #33FF33; }");

		sb.append("table.passed tr.stripe td, table tr.skippedodd td { 	background-color: #cccccc; }");

		sb.append("table.passed td, table tr.skippedodd td { 	background-color: #dddddd; }");

		sb.append(
				"table.fail tr.stripe td, table tr.failedodd td, table.result td.numi_attn 	{	background-color: #FF3333;}");

		sb.append(
				"table.fail td, table tr.failedeven td, table.result tr.stripe td.numi_attn {	background-color:  #e6b0aa ;}");

		sb.append("tr.stripe td, tr.stripe th {	background-color: #E6EBF9;}");

		sb.append("p.totop {	font-size: 85%;	text-align: center;	border-bottom: 2px black solid}");

		sb.append("div.shootout {	padding: 2em;	border: 3px #4854A8 solid}");
		sb.append("</style>").append("</head>");
		return sb.toString();
	}

}
