package bin.webAppAutomation.Main.Java.EmailReport;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

//import javax.swing.text.Document;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.w3c.dom.NodeList;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class ExcelReportGenerator {

	public void generateExcelReport(String destFileName)
			throws SAXException, IOException, ParserConfigurationException {

		// String path =
		// ExcelReportGenerator.class.getClassLoader().getResource("./").getPath();
		// path = path.replaceAll("bin", "src");
		// File xmlFile = new File(path + "../name of path");
		File xmlFile = new File(System.getProperty("user.dir") + "/target/surefire-reports/testng-results.xml");
		DocumentBuilderFactory fact = DocumentBuilderFactory.newInstance();
		DocumentBuilder build = fact.newDocumentBuilder();
		Document doc = build.parse(xmlFile);
		double countPass = 0, countFail = 0, countSkip = 0.0;
		// doc.getDefaultRootElement().normalize();
		XSSFWorkbook book = new XSSFWorkbook();
		int r = 0;
		//////
		String totalDuration = null;
		NodeList test_list = doc.getElementsByTagName("test");
		for (int i = 0; i < test_list.getLength(); i++) {

			Node test_node = test_list.item(i);
			String test_name = ((Element) test_node).getAttribute("name");
			XSSFSheet sheet = book.createSheet(test_name);
			String total_duration = ((Element) test_node).getAttribute("duration-ms");
			int intTotalDuration = Integer.parseInt(total_duration);

			totalDuration = String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(intTotalDuration),
					TimeUnit.MILLISECONDS.toSeconds(intTotalDuration)
							- TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(intTotalDuration)));

			NodeList class_list = ((Element) test_node).getElementsByTagName("class");

			for (int j = 0; j < class_list.getLength(); j++) {

				Node class_node = class_list.item(j);
				String class_name = ((Element) class_node).getAttribute("name");
				NodeList test_method_list = ((Element) test_node).getElementsByTagName("test-method");
				for (int k = 0; k < test_method_list.getLength(); k++) {

					Node test_method_node = test_method_list.item(k);
					String test_method_name = ((Element) test_method_node).getAttribute("name");
					String test_duration = ((Element) test_method_node).getAttribute("duration-ms");
					int hms = Integer.parseInt(test_duration);
					String hms1 = String.format("%02d:%02d", TimeUnit.MILLISECONDS.toMinutes(hms),
							TimeUnit.MILLISECONDS.toSeconds(hms)
									- TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(hms)));
					String test_method_status = ((Element) test_method_node).getAttribute("status");
					if ("CM".equalsIgnoreCase(test_method_name.substring(0, 2))) {
						System.out.println(test_method_name);
						XSSFRow row = sheet.createRow(r++);
						XSSFCell cel_name = row.createCell(0);
						cel_name.setCellValue(test_method_name);
						XSSFCell cel_status = row.createCell(1);
						cel_status.setCellValue(test_method_status);
						XSSFCell cel_duration = row.createCell(2);
						cel_duration.setCellValue(hms1);
						XSSFCell cel_exp;
						String exp_msg;
						if (test_method_status.equalsIgnoreCase("PASS")) {
							countPass++;
						} else if (test_method_status.equalsIgnoreCase("FAIL")) {
							countFail++;
						} else {
							countSkip++;
						}

						if ("FAIL".equalsIgnoreCase(test_method_status)) {

							NodeList exp_list = ((Element) test_method_node).getElementsByTagName("exception");
							Node exp_node = exp_list.item(0);
							exp_msg = ((Element) exp_node).getAttribute("class").toString();
							cel_exp = row.createCell(3);
							cel_exp.setCellValue(exp_msg);
						}
					}
					if (k == test_method_list.getLength()) {
						break;
					}
				}
				if (j == 0) {
					break;
				}
			}
			if (i == 1) {
				break;
			}
		}
		double totalValue = countFail + countPass + countSkip;
		XSSFSheet sheet2 = book.createSheet("Test Count");

		XSSFRow rowName = sheet2.createRow(0);
		XSSFCell totalPass = rowName.createCell(0);
		totalPass.setCellValue("Passed");

		XSSFCell totalFail = rowName.createCell(1);
		totalFail.setCellValue("Failed");

		XSSFCell totalSkip = rowName.createCell(2);
		totalSkip.setCellValue("Skipped");

		XSSFCell totalTest = rowName.createCell(3);
		totalTest.setCellValue("Total Count");

		XSSFCell totalTimeTaken = rowName.createCell(4);
		totalTimeTaken.setCellValue("Total Execution Time");

		XSSFRow row2 = sheet2.createRow(1);
		XSSFCell count_pass = row2.createCell(0);
		count_pass.setCellValue(countPass);

		XSSFCell count_fail = row2.createCell(1);
		count_fail.setCellValue(countFail);

		XSSFCell count_skip = row2.createCell(2);
		count_skip.setCellValue(countSkip);

		XSSFCell count_total = row2.createCell(3);
		count_total.setCellValue(totalValue);

		XSSFCell count_time = row2.createCell(4);
		count_time.setCellValue(totalDuration);

		String destFilePath = System.getProperty("user.dir") + "/bin/webAppAutomation/Main/Java/EmailReport/"
				+ destFileName;
		File xlsFile = new File(destFilePath);
		if (xlsFile.exists()) {
			xlsFile.delete();
		}
		FileOutputStream fout = new FileOutputStream(destFilePath);

		book.write(fout);

		fout.close();

		System.out.println("Report generated");
	}

	public static void main(String args[]) throws SAXException, IOException, ParserConfigurationException {
		ExcelReportGenerator excel = new ExcelReportGenerator();
		excel.generateExcelReport("report.xlsx");
		try {
			Runtime.getRuntime().exec(new String[] { "wscript.exe",
					System.getProperty("user.dir") + "/bin/webAppAutomation/Main/Java/EmailReport/SendEmail.vbs" });
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}