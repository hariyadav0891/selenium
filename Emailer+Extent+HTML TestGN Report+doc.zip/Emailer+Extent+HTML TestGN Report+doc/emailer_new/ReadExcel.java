package bin.webAppAutomation.Main.Java.EmailReport;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {

	public static final String PATH = System.getProperty("user.dir")
			+ "/bin/webAppAutomation/Main/Java/ExtentReportListener/CMES_Automation_Report_Win_1709.html";
	public static final String FILENAME = System.getProperty("user.dir")
			+ "/bin/webAppAutomation/Main/Java/EmailReport/report.xlsx";
	public String path;
	FileInputStream fis;
	XSSFWorkbook workbook;
	XSSFSheet sheet;
	XSSFRow row;
	XSSFCell cell;

	public void Excel_Reader(String path, String filename) throws IOException {
		this.path = path;
		FileWriter fstream = null;
		BufferedWriter out = null;
		fstream = new FileWriter(filename);
		out = new BufferedWriter(fstream);
		long RUN_DATE = System.nanoTime();
		String testStartTime = null;
		// code to create header
		out.newLine();

		out.write("<html>\n");
		out.write("<HEAD>\n");
		out.write(" <TITLE>Automation Test Results</TITLE>\n");
		out.write("</HEAD>\n");

		out.write("<body>\n");
		out.write(
				"<h4 align=center><FONT COLOR=660066 FACE=AriaL SIZE=6><b><u> Automation Test Results</u></b></h4>\n");
		out.write("<table  border=1 cellspacing=1 cellpadding=1 >\n");
		out.write("<tr>\n");

		out.write("<h4> <FONT COLOR=660000 FACE=Arial SIZE=4.5> <u>Test Details :</u></h4>\n");
		out.write(
				"<td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run Date</b></td>\n");
		out.write("<td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>" + RUN_DATE + "</b></td>\n");
		out.write("</tr>\n");
		out.write("<tr>\n");

		out.write(
				"<td width=150 align=left bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE=Arial SIZE=2.75><b>Run StartTime</b></td>\n");

		out.write("<td width=150 align=left><FONT COLOR=#153E7E FACE=Arial SIZE=2.75><b>" + testStartTime
				+ "</b></td>\n");
		out.write("</tr>\n");
		out.write("<tr>\n");
		// out.newLine();
		out.write(
				"<td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Run EndTime</b></td>\n");
		out.write("<td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>END_TIME</b></td>\n");
		out.write("</tr>\n");
		out.write("<tr>\n");
		// out.newLine();

		out.write(
				"<td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Environment</b></td>\n");
		out.write("<td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>" + "Win10 v1709"
				+ "</b></td>\n");
		out.write("</tr>\n");
		out.write("<tr>\n");

		out.write(
				"<td width=150 align= left  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2.75><b>Release</b></td>\n");
		out.write(
				"<td width=150 align= left ><FONT COLOR=#153E7E FACE= Arial  SIZE=2.75><b>" + "v1709" + "</b></td>\n");
		out.write("</tr>\n");

		out.write("</table>\n");
		out.write("<h4> <FONT COLOR=660000 FACE= Arial  SIZE=4.5> <u>" + "RFC" + " Report :</u></h4>\n");
		out.write("<table  border=1 cellspacing=1 cellpadding=1 width=100%>\n");
		out.write("<tr>\n");
		out.write(
				"<td width=10%  align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Test Script#</b></td>\n");

		out.write(
				"<td width=40% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Test Case Name</b></td>\n");
		out.write(
				"<td width=10% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Status</b></td>\n");
		out.write(
				"<td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Run Start Time</b></td>\n");
		out.write(
				"<td width=20% align= center  bgcolor=#153E7E><FONT COLOR=#E0E0E0 FACE= Arial  SIZE=2><b>Run End Time</b></td>\n");
		out.write("</tr>\n");

		try {
			fis = new FileInputStream(path);
			workbook = new XSSFWorkbook(fis);
			sheet = workbook.getSheetAt(0);
			int i = 0;
			// Iterator<Row> rowIterator = sheet.iterator();
			// while (rowIterator.hasNext()) {
			for (int j = 0; j <= sheet.getPhysicalNumberOfRows(); j++) {
				// Row row = rowIterator.next();
				String testName = row.getCell(0).getStringCellValue();
				String testStatus = row.getCell(1).getStringCellValue();
				String testTime = row.getCell(2).getStringCellValue();
				String testException = row.getCell(3).getStringCellValue();
				out.write("<tr> ");

				out.write("<td align=center width=10%><FONT COLOR=#153E7E FACE=Arial SIZE=1><b>TS" + (i + 1)
						+ "</b></td>");
				out.write("<td align=center width=50%><FONT COLOR=#153E7E FACE=Arial SIZE=1><b>" + testName
						+ "</b></td>");

				if (testStatus.equalsIgnoreCase("PASS")) {
					out.write("<td width=20% align= center  bgcolor=#BCE954><FONT COLOR=#153E7E FACE=Arial SIZE=2><b>"
							+ testStatus + "</b></td>\n");
				} else if (testStatus.equalsIgnoreCase("Fail")) {
					out.write("<td width=20% align= center  bgcolor=Red><FONT COLOR=#153E7E FACE= Arial  SIZE=2><b>"
							+ testStatus + "</b></td>\n");
				}
				out.write("<td align=center width=10%><FONT COLOR=#153E7E FACE=Arial SIZE=1><b>" + testTime
						+ "</b></td>");
				out.write("<td align=center width=50%><FONT COLOR=#153E7E FACE=Arial SIZE=1><b>" + testException
						+ "</b></td>");
				// out.write("<td align=center width=20%><FONT
				// COLOR=#153E7E FACE=Arial
				// SIZE=1><b>"+teststatus.get(i)+"</b></td>");
				/*
				 * if (screenShotPath.get(i) != null) out.
				 * write("<td align=center width=20%><FONT COLOR=#153E7E FACE=Arial SIZE=1><b><a href="
				 * + screenShotPath.get(i) +
				 * " target=_blank>Screen Shot</a></b></td>"); else out.
				 * write("<td align=center width=20%><FONT COLOR=#153E7E FACE=Arial SIZE=1><b>&nbsp;</b></td>"
				 * );
				 */
				out.write("</tr>");

			}
			out.write("</table>");
			out.write("</body>");
			out.write("</html>");
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String args[]) throws IOException {
		ReadExcel ex = new ReadExcel();
		ex.Excel_Reader(PATH, FILENAME);
	}
}
