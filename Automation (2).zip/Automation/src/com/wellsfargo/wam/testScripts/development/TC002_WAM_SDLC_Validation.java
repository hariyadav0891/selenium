package com.wellsfargo.wam.testScripts.development;

import java.io.IOException;
import java.util.Iterator;

import jxl.read.biff.BiffException;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wellsfargo.wam.common.BaseTestCase;
import com.wellsfargo.wam.pages.WAM_Home_Page;
import com.wellsfargo.wam.pages.WAM_SDLC;

public class TC002_WAM_SDLC_Validation extends BaseTestCase {

public static final Logger log = Logger.getLogger(TC002_WAM_SDLC_Validation.class.getName());	
public static String app_name="GLOBAL PAYMENT SYSTEM";
public static String Assert_type="Application";
//	oWAMHome.searchForApp(app_name ,"Application");
	@BeforeClass
	public void setUp() throws IOException{
     init();
	}
	
	
	//Have test and production environments been established with proper permission levels?
	@Test(priority=0)
	public void TC002_1_production_Environments_Established_Permission() throws BiffException, IOException{
		log("=========== Starting TC002_1_production_Environments_Established_Permission Test=============");
		WAM_SDLC osdlc= new WAM_SDLC();
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.searchForApp(app_name ,"Application");
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.established_With_Permission("Select");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val =oWAMHome.viewPagevalidationOfQuestion("Have test and production environments been established with proper permission levels?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Have test and production environments been established with proper permission levels"));
		log("=========== Finshed TC002_1_production_Environments_Established_Permission Test=============");
	}
	
	//Validation:--Have test and production environments been established with proper permission levels?
	@Test(priority=1)
	public void TC002_2_Validation_production_Environments_Established_Permission() throws  InterruptedException{
		log("=========== Starting TC002_2_Validation_production_Environments_Established_Permission Test=============");
		WAM_SDLC osdlc= new WAM_SDLC();
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.established_With_Permission("Yes");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Have test and production environments been established with proper permission levels?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation		
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Have test and production environments been established with proper permission levels"));
		log("=========== Finshed TC002_2_Validation_production_Environments_Established_Permission Test=============");
	}
	//Has the application been added to SD Elements?
	@Test(priority=2)
	public void TC002_3_application_Been_Added_to_SD_Elements()  {
		log("=========== Starting TC002_3_application_Been_Added_to_SD_Elements Test=============");
		WAM_SDLC osdlc= new WAM_SDLC();
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.addToSDElement("Select");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Pending Input";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Has the application been added to SD Elements?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation				
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Has the application been added to SD Elements?"));	
		log("=========== Finshed TC002_3_application_Been_Added_to_SD_Elements Test=============");
	}
		
	//Validation:--Has the application been added to SD Elements?
	@Test(priority=3)
	public void TC002_4_Validation_application_Been_Added_to_SD_Elements()   {
		log("=========== Starting TC002_4_Validation_application_Been_Added_to_SD_Elements Test=============");
		WAM_SDLC osdlc= new WAM_SDLC();
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.addToSDElement("No");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="No";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Has the application been added to SD Elements?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Has the application been added to SD Elements?"));
		log("=========== Finshed TC002_4_Validation_application_Been_Added_to_SD_Elements Test=============");
	}
			
	//Software type
	@Test(priority=4)
	public void TC002_5_Software_type()   {
		log("=========== Starting TC002_5_Software_type Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_SDLC osdlc= new WAM_SDLC();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.softwareType("Select");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Software Type");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Software Type"));
		log("=========== Finshed TC002_5_Software_type Test=============");
	}
	
	//Validation:-Software type
	@Test(priority=5)
	public void TC002_6_Validation_Software_type()  {
		log("=========== Starting TC002_6_Validation_Software_type Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_SDLC osdlc= new WAM_SDLC();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.softwareType("Package (Off the Shelf)");
		osdlc.software_Installed_Running("WF Datacenter");
		osdlc.software_Installed_Running("Third Party Datacenter");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Package (Off the Shelf)";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Software Type");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Software Type"));
		log("=========== Finshed TC002_6_Validation_Software_type Test=============");
	}
	//Is all code built/compiled in a development/build environment?
	@Test(priority=6)
	public void TC002_7_compiled_Development_Environment()   {
		log("=========== Starting TC002_7_compiled_Development_Environment Test=============");
		WAM_SDLC osdlc= new WAM_SDLC();
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.buildEnvironment("Select");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Is all code built/compiled in a development/build environment?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Is all code built/compiled in a development/build environment?"));
		log("=========== Finshed TC002_7_compiled_Development_Environment Test=============");
	}
		
	//Validation:-Is all code built/compiled in a development/build environment?
	@Test(priority=7)
	public void TC002_8_Validation_compiled_Development_Environment()   {
		log("=========== Starting TC002_8_Validation_compiled_Development_Environment Test=============");
		WAM_SDLC osdlc= new WAM_SDLC();
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		osdlc.buildEnvironment("Yes");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Is all code built/compiled in a development/build environment?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation		
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Is all code built/compiled in a development/build environment?"));
		log("=========== Finshed TC002_8_Validation_compiled_Development_Environment Test=============");
	}	
	//Build & Release Team for Deployments
	@Test(priority=8)
		public void TC002_9_Build_Release_Team_Deployments()   {
		log("=========== Starting TC002_9_Build_Release_Team_Deployments Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_SDLC osdlc= new WAM_SDLC();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		oWAMHome.checkBooxISSelected("CAMS(Code Application Migration Services)");
		oWAMHome.checkBooxISSelected("CBT-DCT(Community Bank Technology-Digital Channels Technology)");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="CAMS(Code Application Migration Services)" ;
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Build & Release Team for Deployments(Distributed)");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation				
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Build & Release Team for Deployments(Distributed)"));
		log("=========== Finshed TC002_9_Build_Release_Team_Deployments Test=============");
	}
	
	//Indicate where the code/software is installed/running? (select all that apply)
	@Test(priority=9)
	public void TC002_10_Software_Is_Installed()  {
		log("=========== Starting TC002_10_Software_Is_Installed Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_SDLC osdlc= new WAM_SDLC();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		oWAMHome.checkBooxISSelected("WF Datacenter");
		oWAMHome.checkBooxISSelected("Third Party Datacenter");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="WF Datacenter";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Indicate where the code/software is installed/running?");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation	
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Indicate where the code/software is installed/running?"));
		log("=========== Finshed TC002_10_Software_Is_Installed Test=============");
	}
	
	//Roles & Responsibilities:-	Select the roles involved in building and deploying the code
	@Test(priority=10)
	public void TC002_11_Select_Roles_Responsibilities()   {
		log("=========== Starting TC002_11_Select_Roles_Responsibilities Test=============");
		WAM_SDLC osdlc= new WAM_SDLC();
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("SDLC");
		oWAMHome.checkBooxISSelected("Developer");
		osdlc.clickSaveButton();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Developer";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Select the roles involved in building and deploying the code");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Select the roles involved in building and deploying the code"));
		log("=========== Finshed TC002_11_Select_Roles_Responsibilities Test=============");
		}
	
}
