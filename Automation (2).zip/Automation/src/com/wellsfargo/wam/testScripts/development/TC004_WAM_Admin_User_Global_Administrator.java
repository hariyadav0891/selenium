package com.wellsfargo.wam.testScripts.development;

import java.io.IOException;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wellsfargo.wam.common.BaseTestCase;
import com.wellsfargo.wam.pages.WAM_Admin_Users;
import com.wellsfargo.wam.pages.WAM_Home_Page;

public class TC004_WAM_Admin_User_Global_Administrator extends BaseTestCase{
public static final Logger log = Logger.getLogger(TC004_WAM_Admin_User_Global_Administrator.class.getName());	
	String App_id="15481";
	@BeforeClass
public void setUp() throws IOException{
     init();
	}

	@Test(priority=0)
	public void TC004_1_Verify_Global_Administrator_Roles(){
		log("=========== Starting TC004_1_Verify_Global_Administrator_Roles Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_Admin_Users ouser= new WAM_Admin_Users();
		oWAMHome.clickOnNavigationMenu("Admin");
		oWAMHome.clickOnNavigationMenu("Users");
		ouser.searchForLanID("u608899");
		ouser.clickOnEditLink.click();
		log("Clicking on Edit Link ");
		Assert.assertTrue(true);
		log("Global Administrator Roles is already given to User ");
		log("=========== Finshed TC004_1_Verify_Global_Administrator_Roles Test=============");
		}
	/*
	@Test(dependsOnMethods="TC004_1_Verify_Global_Administrator_Roles" ,priority=1)
	public void TC004_2_remove_Global_Administrator_Roles(){
		log("=========== Starting TC004_2_remove_Global_Administrator_Roles Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		Admin_Users ouser= new Admin_Users();
		oWAMHome.clickOnNavigationMenu("Admin");
		oWAMHome.clickOnNavigationMenu("Users");
		ouser.searchForLanID("u608899");
		ouser.clickOnEditLink.click();
		log("Clicking on Edit Link ");
		ouser.gAdministrator.click();
		ouser.clickONSave.click();
		Assert.assertTrue(false);
		log("Global Administrator Roles is Removed from  User ");	
		log("=========== Finshed TC004_2_remove_Global_Administrator_Roles Test=============");
	}
	*/

	@Test(priority=2)
	public void TC004_3_Update_App_Roles(){
		log("=========== Starting TC004_3_Update_App_Roles Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_Admin_Users ouser= new WAM_Admin_Users();
		oWAMHome.clickOnNavigationMenu("Admin");
		oWAMHome.clickOnNavigationMenu("Users");
		ouser.searchForLanID("u608899");
		ouser.clickOnEditLink.click();
		log("Clicking on Edit Link ");
		ouser.updateAppRole();
		@SuppressWarnings("unused")
		Iterator<String> itr = getAllWindow();
		ouser.seaechBYAPPId();
		waitforElement(3, ouser.appIDD);
		ouser.appIDD.sendKeys("15481");
		ouser.appIDD.sendKeys(Keys.ENTER);
		log("Enter App ID  ");
		waitforElement(3, ouser.searchButton);
		ouser.searchButton.click();
		log("Clicking on Check Button");
		ouser.editRoles("Business Owner");
		ouser.editRoles("Read Access");
		waitforElement(5, ouser.clickOnSaveButton);
		ouser.clickOnSaveButton.click();
		log("Clicking on Save Button");
		Assert.assertTrue(true);
		log("=========== Finshed TC004_3_Update_App_Roles Test=============");
	}	
	
}
