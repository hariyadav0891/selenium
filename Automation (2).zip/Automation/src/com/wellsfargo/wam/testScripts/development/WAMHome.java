package com.wellsfargo.wam.testScripts.development;

import org.openqa.selenium.Keys;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.wellsfargo.wam.common.BaseTestCase;
import com.wellsfargo.wam.common.WAMData;
import com.wellsfargo.wam.pages.WAMLogin;

public class WAMHome extends BaseTestCase {
	
		@Test
		public void WAM_1() {
		    String expectedTitle = "WAM - Home Page"; 
		    String actual = driver.getTitle();
		    System.out.println("The title is "+actual);
		    Assert.assertEquals(actual, expectedTitle, "Test Case Pass");
              
		}
	
		@Test
		public void WAM_2() {
			String expectedTitle = "WAM - Home Page"; 
			String actual = driver.getTitle();
			System.out.println("The title is "+actual);
			Assert.assertEquals(actual, expectedTitle, "Test Case Pass");
	          
		}
		
		@Test(enabled = false)
		public void WAM_3() throws Exception {
			WAMLogin oWAMLogin = new WAMLogin();
			oWAMLogin.buttonClose.click();
			String user1 = readExcel("Sheet1", "user5");
			System.out.println("User : "+user1);
			String user2 = readExcel("Sheet2", "BNG");
			System.out.println("BNG : "+user2);		     
	          
		}
		
		@Test(enabled = false)
		public void WAM_4() throws Exception {
			WAMLogin oWAMLogin = new WAMLogin();
			oWAMLogin.buttonClose.click();
			WAMData oWAMData = getWAMdata(2);
			String name = oWAMData.getName();
			System.out.println("Name is :: "+name);
			String city = oWAMData.getCity();
			System.out.println("\n\nCity is :: "+city);
			  
		}
		
		@Test(enabled = false)
		public void WAM_5() throws Exception {
			WAMLogin oWAMLogin = new WAMLogin();
			WAMData oWAMData = getWAMdata(17);
			String appName = oWAMData.getName();
			oWAMLogin.buttonAllApps.click();
					
			sendkeys(appName, oWAMLogin.searchNameField);
	        oWAMLogin.searchNameField.sendKeys(Keys.ENTER);			
			  
		}
		
		@Test(enabled = false)
		public void WAM_6() throws Exception {
			WAMLogin oWAMLogin = new WAMLogin();
			WAMData oWAMData = getWAMdata(17);
			String appName = oWAMData.getName();
			oWAMLogin.buttonAllApps.click();
		
			sendkeys(appName, oWAMLogin.searchNameField);
			oWAMLogin.searchNameField.sendKeys(Keys.ENTER);	
	        
	        oWAMLogin.linkInput.click();
	        oWAMLogin.buttonTechnicalInput.click();
	        String actualText = oWAMLogin.textTechnicalApplicationOverview.getText();
	        Assert.assertEquals(actualText, "Technical Application Overview", "Test Case Failed, It is not matching");
	        	        
		}
}
