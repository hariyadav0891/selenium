package com.wellsfargo.wam.testScripts.development;

import java.io.IOException;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wellsfargo.wam.common.BaseTestCase;
import com.wellsfargo.wam.pages.WAM_Home_Page;
import com.wellsfargo.wam.pages.WAM_TechnicalApplicationOverview;

public class TC003_WAM_TechnicalApplicationOverview extends BaseTestCase {
public static final Logger log = Logger.getLogger(TC003_WAM_TechnicalApplicationOverview.class.getName());	
public static String app_name="GLOBAL PAYMENT SYSTEM";
public static String Assert_type="Application";
//oWAMHome.searchForApp(app_name ,"Application");
	@BeforeClass
	public void setUp() throws IOException{
     init();
	}
	//Is there a Website?
	@Test(priority=0)
	public void TC003_1_Is_Website() {
		log("=========== Starting TC003_1_Is_Website Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.searchForApp(app_name ,"Application");
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("Is there a Website?", "Select");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Is there a website?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Is there a website?"));
		log("=========== Finshed TC003_1_Is_Website Test=============");
	}
	//Validation:-Is there a Website?
	@Test(priority=1)
	public void TC003_2_Validate_Is_Website() {
		log("=========== Starting TC003_2_Validate_Is_Website Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("Is there a Website?", "Yes");
		oWAMHome.checkBooxISSelected("Internet");
		oTechOverview.websitSubQue("Internet");
		oTechOverview.websitURL.clear();
		oTechOverview.websitURL.sendKeys("test.com");
		log("Application Production Website URL ");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Is there a website?");
		String Expected_val1 = oWAMHome.viewPagevalidationOfQuestion("Application Production Websit");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		Assert.assertEquals("test.com", Expected_val1);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Is there a website?"));
		log("=========== Finshed TC003_2_Validate_Is_Website Test=============");
		}
	//Does this application use Tealeaf to capture session data?
	@Test(priority=2)
	public void TC003_3_Tealeaf_Capture_Session_Data()   {
		log("=========== Starting TC003_3_Tealeaf_Capture_Session_Data Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("Does this application use Tealeaf to capture session data?", "Select");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does this application use Tealeaf to capture session data?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Does this application use Tealeaf to capture session data?"));
		log("=========== Finshed TC003_3_Tealeaf_Capture_Session_Data Test=============");
	}
	//Validation:-Does this application use Tealeaf to capture session data?
	@Test(priority=3)
	public void TC003_4_Validate_Tealeaf_Capture_Session_Data()   {
		log("=========== Starting TC003_4_Validate_Tealeaf_Capture_Session_Data Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("Does this application use Tealeaf to capture session data?", "Yes");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does this application use Tealeaf to capture session data?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Does this application use Tealeaf to capture session data?"));
		log("=========== Finshed TC003_4_Validate_Tealeaf_Capture_Session_Data Test=============");
	}	
	//What is the preferred Method for support team engagement?
	@Test(priority=4)
	public void TC003_5_Preferred_Method_Support_Team_Engagement()   {
		log("=========== Starting TC003_5_Preferred_Method_Support_Team_Engagement Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("What is the preferred Method for support team engagement?", "Select");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("What is the preferred Method for support team engagement?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("What is the preferred Method for support team engagement?"));
		log("=========== Finshed TC003_5_Preferred_Method_Support_Team_Engagement Test=============");
	}
	//What is the preferred Method for support team engagement?
	@Test(priority=5)
	public void TC003_6_Validation_Preferred_Method_Support_Team_Engagement()   {
		log("=========== Starting TC003_6_Validation_Preferred_Method_Support_Team_Engagement Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("What is the preferred Method for support team engagement?", "PAC2000 OCP");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="PAC2000 OCP";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("What is the preferred Method for support team engagement?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("What is the preferred Method for support team engagement?"));
		log("=========== Finshed TC003_6_Validation_Preferred_Method_Support_Team_Engagement Test=============");
	}
	//Does your application have an Everbridge IT Alerting Group?	
	@Test(priority=6)
	public void TC003_7_Everbridge_IT_Alerting_Group()   {
		log("=========== Starting TC003_7_Everbridge_IT_Alerting_Group Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("Does your application have an Everbridge IT Alerting Group?", "Select");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does your application have an Everbridge IT Alerting Group?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		log("=========== Finshed TC003_7_Everbridge_IT_Alerting_Group Test=============");
	}	
	//Does your application have an Everbridge IT Alerting Group?	
	@Test(priority=7)
	public void TC003_8_Validate_Everbridge_IT_Alerting_Group()   {
		log("=========== Starting TC003_8_Validate_Everbridge_IT_Alerting_Group Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("Does your application have an Everbridge IT Alerting Group?", "Yes");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does your application have an Everbridge IT Alerting Group?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		log("=========== Finshed TC003_8_Validate_Everbridge_IT_Alerting_Group Test=============");
	}		
}