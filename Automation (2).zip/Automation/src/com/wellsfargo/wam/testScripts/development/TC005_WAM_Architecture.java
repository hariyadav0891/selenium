package com.wellsfargo.wam.testScripts.development;

import java.io.IOException;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wellsfargo.wam.common.BaseTestCase;
import com.wellsfargo.wam.pages.WAM_Architecture;
import com.wellsfargo.wam.pages.WAM_Home_Page;

public class TC005_WAM_Architecture extends BaseTestCase {

public static final Logger log = Logger.getLogger(TC005_WAM_Architecture.class.getName());	
	//WAMOperationalRisk oWAMOR= new WAMOperationalRisk();
public static String app_name="GLOBAL PAYMENT SYSTEM";
public static String Assert_type="Application";
	@BeforeClass
	public void setUp() throws IOException{
     init();
	}
	//Application Specification:-Application Platform

	@Test(priority=0)
	public void TC005_1_verify_Application_platform()  {
		log("=========== Starting TC005_1_verify_Application_platform Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		oWAMHome.checkBooxISSelected("MAINFRAME");
		oWAMHome.checkBooxISSelected("MIDRANGE");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="MAINFRAME";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Application Platform");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		System.out.println("contains"+contains);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Application Platform"));
		log("=========== Finshed TC005_1_verify_Application_platform Test=============");
	}
	//Application Category
	@Test(priority=1)
	public void TC005_2_verify_Application_Catgegory()  {
		log("=========== Starting TC005_2_verify_Application_Catgegory Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_Architecture oWAMARCH= new WAM_Architecture();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		oWAMARCH.app_category("Custom - Externally Hosted");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Custom - Externally Hosted";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Application Category");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Application Category"));
		log("=========== Finshed TC005_2_verify_Application_Catgegory Test=============");
	}
	//Database Type
	@Test(priority=2)
	public void TC005_3_verify_DataBase_Type()  {
		log("=========== Starting TC005_3_verify_DataBase_Type Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		oWAMHome.checkBooxISSelected("Access");
		oWAMHome.checkBooxISSelected("DB2");
		oWAMHome.checkBooxISSelected("MySQL");
		oWAMHome.checkBooxISSelected("Oracle");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Oracle";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Database Type");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		System.out.println("contains"+contains);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Database Type"));
		log("=========== Finshed TC005_3_verify_DataBase_Type Test=============");
	}
	//Primary Use of Data
	@Test(priority=3)
	public void TC005_4_VerifyPrimary_Use_Data()  {
		log("=========== Starting TC005_4_VerifyPrimary_Use_Data Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		oWAMHome.checkBooxISSelected("Business Rule Store");
		oWAMHome.checkBooxISSelected("Data Mart (Analytic)");
		oWAMHome.checkBooxISSelected("Operational Datastore");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Operational Datastore";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Primary Use of the Data ");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		System.out.println("contains"+contains);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Primary Use of the Data "));
		log("=========== Finshed TC005_4_VerifyPrimary_Use_Data Test=============");
	}
	//Portal/Channel
	@Test(priority=4)
	public void TC005_5_verify_Channel()  {
		log("=========== Starting TC005_5_verify_Channel Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		oWAMHome.checkBooxISSelected("CEO Mobile Portal");
		oWAMHome.checkBooxISSelected("Non Portal/Channel Application");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="CEO Mobile Portal";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Portal/Channel");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		System.out.println("contains"+contains);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Portal/Channel"));
		log("=========== Finshed TC005_5_verify_Channel Test=============");
	}
	//Does this application feed from or rely on batch jobs?
	@Test(priority=5)
	public void TC005_6_verify_Application_Feed_Batch_Job()  {
		log("=========== Starting TC005_6_verify_Application_Feed_Batch_Job Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_Architecture oWAMARCH= new WAM_Architecture();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		oWAMARCH.application_batch_job("Yes");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does this application feed from or rely on batch jobs?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Does this application feed from or rely on batch jobs?"));
		log("=========== Finshed TC005_6_verify_Application_Feed_Batch_Job Test=============");
	}
	//Architecture Model
	@Test(priority=6)
	public void TC005_7_verify_Architecture_Model()  {
		log("=========== Starting TC005_7_verify_Architecture_Model Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_Architecture roWAMARCH= new WAM_Architecture();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		roWAMARCH.architectureModel("Internal Application");
		roWAMARCH.architectureartifacts("Yes");
		roWAMARCH.applicationRoadmapl("Yes");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Internal Application";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Architectural Model");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		String actual_val1="Yes";
		String Expected_val1 = oWAMHome.viewPagevalidationOfQuestion("Are the application architectural artifacts housed in Wholesale Architectural Library (WAL)?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val1, Expected_val1);
		String actual_val2="Yes";
		String Expected_val2 = oWAMHome.viewPagevalidationOfQuestion("Does the application have a Roadmap?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val2, Expected_val2);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Architectural Model"));
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Does the application have a Roadmap?"));
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Is the application Architectural Artifacts housed in WAL?"));
		log("=========== Finshed TC005_7_verify_Architecture_Model Test=============");
	}
	//Network Environments
	@Test(priority=7)
	public void TC005_8_verify_Network_Environments()  {
		log("=========== Starting TC005_8_verify_Network_Environments Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_Architecture oWAMARCH= new WAM_Architecture();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Architecture");
		oWAMARCH.NetWorkEnvironments("Gold Net");
		oWAMHome.checkBooxISSelected("Dial up via modem");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Gold Net";
		String actual_val2="Dial up via modem";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Network Environment");
		String Expected_val2 = oWAMHome.viewPagevalidationOfQuestion("Remote Access for Maintenance and Production Support ");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		boolean contains = Expected_val2.contains(actual_val2);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation			
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Network Environment"));
		log("=========== Finshed TC005_8_verify_Network_Environments Test=============");
	}
}
	
	
	

