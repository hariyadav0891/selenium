package com.wellsfargo.wam.testScripts.development;

import java.io.IOException;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.wellsfargo.wam.common.BaseTestCase;
import com.wellsfargo.wam.pages.WAMOperationalRisk;
import com.wellsfargo.wam.pages.WAM_Home_Page;

public class TC001_WAMOperationalRiskTests extends BaseTestCase {
	public static final Logger log = Logger.getLogger(TC001_WAMOperationalRiskTests.class.getName());
	public static String app_name="GLOBAL PAYMENT SYSTEM";
	public static String Assert_type="Application";
	
	@BeforeClass
	public void setUp() throws IOException {
		init();
	}

	//=====================Data Extraction and Transmission=============================
	@Test(priority = 0)
	public void TC001_1_verifyApplicationAllowDataExtractions() {
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		log("=========== Starting TC001_1_verifyApplicationAllowDataExtractions Test=============");
		WAMOperationalRisk oWAMOR = new WAMOperationalRisk();
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		// Does the application allow data extractions?
		oWAMOR.applicationAllowDataExtractions("Select");
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does the application allow data extractions?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		// Technical Validation page
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		log("Click on Validation Button on validation Page");
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Does the application allow data extractions?"));
		log("=========== Finshed TC001_1_verifyApplicationAllowDataExtractions Test=============");
	}

	@Test(priority = 1)
	public void TC001_2_verifyTechnicalValidationQueSelection()   {
		log("=========== Starting TC001_2_verifyTechnicalValidationQueSelection Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR= new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		oWAMOR.applicationAllowDataExtractions("Yes");
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val =oWAMHome.viewPagevalidationOfQuestion("Does the application allow data extractions?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");
		//  Validation page Validation
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Does the application allow data extractions?"));
		log("Validation Question Is not  Dispayed in Validation Page ");
		log("=========== Finshed TC001_2_verifyTechnicalValidationQueSelection Test=============");
	}

	@Test(priority = 2)
	public void TC001_3_verifyAssetSendDataToThirdParty()   {
		log("=========== Starting TC001_3_verifyAssetSendDataToThirdParty Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR= new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		// Does the asset send/receive data to/from a Third Party/Customer?
		oWAMOR.assetSendDataToThirdParty("Select");
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Pending Input";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does the asset send/receive data to/from a Third Party/Customer?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Does the asset send/receive data to/from a Third Party/Customer?"));
		log("=========== Finshed TC001_3_verifyAssetSendDataToThirdParty Test=============");
	}
	@Test(priority = 3)
	public void TC001_4_TechnicalValidationForAssetSendDataToThirdParty()   {
		log("=========== Starting TC001_4_TechnicalValidationForAssetSendDataToThirdParty Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR= new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		// Does the asset send/receive data to/from a Third Party/Customer?
		oWAMOR.assetSendDataToThirdParty("Both - Send/Receive");
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Both - Send/Receive";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Does the asset send/receive data to/from a Third Party/Customer?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Does the asset send/receive data to/from a Third Party/Customer?"));
		log("=========== Finshed TC001_4_TechnicalValidationForAssetSendDataToThirdParty Test=============");
	}
	
	@Test(priority=4)
	public void TC001_5_methods_is_in_use()    {
		log("=========== Starting TC001_5_methods_is_in_use Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		oWAMHome.checkBooxISSelected("BlueCoat");
		oWAMHome.checkBooxISSelected("Connect: Enterprise (Data Transmission Services - DTS)");
		oWAMHome.checkBooxISSelected("Safe Transmission (Safe-T)");
		oWAMHome.clickSaveButton.click();
		log("Click On Save Button");
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="BlueCoat";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Which of these methods is in use?");
		log("Expected Value is : "+Expected_val);
		boolean contains = Expected_val.contains(actual_val);
		System.out.println("contains"+contains);
		Assert.assertTrue(contains);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false ,oWAMHome.verifyValidationOnValidationPage("Which of these methods is in use?"));
		log("=========== Finshed TC001_5_methods_is_in_use Test=============");
	}
	
	//=====================Risk Assessment===============================================
		//Has an Information Security Risk Assessment (ISRA) been completed for the application?
	@Test(priority = 5)
	public void TC001_6_InformationSecurityRiskAssessment()  {
		log("=========== Starting TC001_6_InformationSecurityRiskAssessment Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR = new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		oWAMOR.informationSecurityRiskAssessment("Select");
		oWAMOR.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Has a Information Security Risk Assessment (ISRA) been completed for the application?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true,oWAMHome.verifyValidationOnValidationPage("Has an Information Security Risk Assessment (ISRA) been completed for the application?"));
		log("=========== Finshed TC001_6_InformationSecurityRiskAssessment Test=============");
	}
	@Test(priority = 6)
	public void TC001_7_verify_Technical_Validation_Information_Risk_Assessment()  {
		log("=========== Starting TC001_7_verify_Technical_Validation_Information_Risk_Assessment Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR = new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		oWAMOR.informationSecurityRiskAssessment("Yes");
		oWAMOR.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Has a Information Security Risk Assessment (ISRA) been completed for the application?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Has an Information Security Risk Assessment (ISRA) been completed for the application?"));
		log("=========== Finshed TC001_7_verify_Technical_Validation_Information_Risk_Assessment Test=============");
	}
	//Information Security Risk Assessment (ISRA) Number: 
	@Test(priority=7)
	public void TC001_8_Security_Risk_Assessment_ISRA_Number()  {
		log("=========== Starting TC001_8_Security_Risk_Assessment_ISRA_Number Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR = new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		oWAMOR.ISRANumber.sendKeys("909624");
		oWAMOR.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="909624";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Information Security Risk Assessment (ISRA) Number");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Information Security Risk Assessment (ISRA) Number"));
		log("=========== Finshed TC001_8_Security_Risk_Assessment_ISRA_Number Test=============");
		
	}
	@Test(priority = 8)
	public void TC001_9_Risk_Assessment_Information()   {
		log("=========== Starting TC001_9_Risk_Assessment_Information Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR = new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		oWAMOR.riskAssessmantInformation("Select");
		//String user1 = readExcel("OperationalRisk", dataISRANumber);
		oWAMOR.uniqreRecordsStore("Select");
		oWAMOR.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="";
		String Expected_val =oWAMHome. viewPagevalidationOfQuestion("Is the Risk Assessment information above accurate?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		String actual_val1="Pending Input";
		String Expected_val1 = oWAMHome.viewPagevalidationOfQuestion("How many unique records are stored and/or transmitted?");
		log("Expected Value is : "+Expected_val1);
		Assert.assertEquals(actual_val1, Expected_val1);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(true, oWAMHome.verifyValidationOnValidationPage("Is the Risk Assessment information above accurate?"));
		Assert.assertEquals(true,oWAMHome. verifyValidationOnValidationPage("How many unique records are stored and/or transmitted?"));
		log("=========== Finshed TC001_9_Risk_Assessment_Information Test=============");
	}
	@Test(priority = 9)
	public void TC001_10_Verify_TechnicalRisk_Assessment_Information()   {
		log("=========== Starting TC001_10_Verify_TechnicalRisk_Assessment_Information Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAMOperationalRisk oWAMOR = new WAMOperationalRisk();
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Operational Risk");
		oWAMOR.riskAssessmantInformation("Yes");
		//String user1 = readExcel("OperationalRisk", dataISRANumber);
		oWAMOR.uniqreRecordsStore("500 - 4,999");
		oWAMOR.clickSaveButton.click();
		//View Page Validation
		oWAMHome.clickOnNavigationMenu(app_name);
		Iterator<String> allWindow = getAllWindow();
		String parentWindow = allWindow.next();
		String childWindow = allWindow.next();
		driver.switchTo().window(childWindow);
		log("Navigate to child window");
		String actual_val="Yes";
		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Is the Risk Assessment information above accurate?");
		log("Expected Value is : "+Expected_val);
		Assert.assertEquals(actual_val, Expected_val);
		String actual_val1="500 - 4,999";
		String Expected_val1 = oWAMHome.viewPagevalidationOfQuestion("How many unique records are stored and/or transmitted?");
		log("Expected Value is : "+Expected_val1);
		Assert.assertEquals(actual_val1, Expected_val1);
		driver.close();
		driver.switchTo().window(parentWindow);
		log("Navigate to Parent window");		
		//  Validation page Validation 
		oWAMHome.clickOnNavigationMenu("Validation");
		oWAMHome.clickOnValidateButton.click();
		Assert.assertEquals(false, oWAMHome.verifyValidationOnValidationPage("Is the Risk Assessment information above accurate?"));
		Assert.assertEquals(false,oWAMHome. verifyValidationOnValidationPage("How many unique records are stored and/or transmitted?"));
		log("=========== Finshed TC001_10_Verify_TechnicalRisk_Assessment_Information Test=============");
	}	
		
// end class	
}
