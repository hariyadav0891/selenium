package com.wellsfargo.wam.testScripts.development;

import java.io.IOException;
import java.util.Iterator;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.wellsfargo.wam.common.BaseTestCase;
import com.wellsfargo.wam.pages.WAMAdHocReportPage;
import com.wellsfargo.wam.pages.WAM_Home_Page;
import com.wellsfargo.wam.pages.WAM_TechnicalApplicationOverview;

public class demo extends BaseTestCase {
public static final Logger log = Logger.getLogger(TC005_WAM_Architecture.class.getName());	
//WAMOperationalRisk oWAMOR= new WAMOperationalRisk();
public static String app_name="GLOBAL PAYMENT SYSTEM";
public static String Assert_type="Application";
	@BeforeClass
	public void setUp() throws IOException{
     init();
	}

	@SuppressWarnings("unused")
	@Test(priority=1)
	public void TC003_2_Validate_Is_Website() throws InterruptedException {
		log("=========== Starting TC003_2_Validate_Is_Website Test=============");
		WAM_Home_Page oWAMHome= new WAM_Home_Page();
		WAM_TechnicalApplicationOverview oTechOverview= new WAM_TechnicalApplicationOverview();
		
		oWAMHome.clickOnNavigationMenu("Home");
		waitforElement(2, oWAMHome.clickMyApp);
		oWAMHome.searchForApp(app_name ,Assert_type);
		oWAMHome.clickOnNavigationMenu("Application Overview");
		oTechOverview.comnmethodSelect("Is there a Website?", "Yes");
		oWAMHome.checkBooxISSelected("Internet");
		oWAMHome.checkBooxISSelected("Intranet");
		oTechOverview.websitURL.clear();
		oTechOverview.websitURL.sendKeys("test.com");
		log("Application Production Website URL ");
		oWAMHome.clickSaveButton.click();
		//View Page Validation
//		oWAMHome.clickOnNavigationMenu(app_name);
//		Iterator<String> allWindow = getAllWindow();
//		String parentWindow = allWindow.next();
//		String childWindow = allWindow.next();
//		driver.switchTo().window(childWindow);
//		log("Navigate to child window");
//		String actual_val="Yes";
//		String Expected_val = oWAMHome.viewPagevalidationOfQuestion("Is there a website?");
//		String Expected_val1 = oWAMHome.viewPagevalidationOfQuestion("Application Production Websit");
//		log("Expected Value is : "+Expected_val);
//		Assert.assertEquals(actual_val, Expected_val);
//		Assert.assertEquals("test.com", Expected_val1);
//		driver.close();
//		driver.switchTo().window(parentWindow);
//		log("Navigate to Parent window");
//		//  Validation page Validation
//		oWAMHome.clickOnNavigationMenu("Validation");
//		oWAMHome.clickOnValidateButton.click();
//		Assert.assertEquals(false,oWAMHome.verifyValidationOnValidationPage("Is there a website?"));
		// Ad-hoc-Report Validation 
		oWAMHome.clickOnNavigationMenu("Home");
		oWAMHome.clickOnNavigationMenu("Reports");
		oWAMHome.adhocReport.click();
		Iterator<String> allWindowad = getAllWindow();
		String adhocparentWindow = allWindowad.next();
		String adhocchildWindow = allWindowad.next();
		driver.switchTo().window(adhocchildWindow);
		WAMAdHocReportPage oAdhocReport = new WAMAdHocReportPage();
		oAdhocReport.deleteFile();
		oAdhocReport.applicationStstus("Deployed");
		oAdhocReport.assetType("Application");
		oAdhocReport.SelectAdHocQuestion("Is there a website?");
		oAdhocReport.SelectAdHocQuestion("Website");
		oAdhocReport.clickOnRunButton.click();
		log("Click On Run Button");
		Thread.sleep(30000*5);
		String expectedval = oAdhocReport.validateAdhocReport("17", "website");
		String actualval = "Internet;Intranet";
		System.out.println("Expected value is : "+expectedval);
		Assert.assertEquals(actualval, expectedval);
				
		log("=========== Finshed TC003_2_Validate_Is_Website Test=============");
		}
}
