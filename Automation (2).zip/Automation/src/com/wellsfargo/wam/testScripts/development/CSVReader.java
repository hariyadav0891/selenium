package com.wellsfargo.wam.testScripts.development;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.io.BufferedReader;
import java.io.IOException;
 
public class CSVReader {

	 public static void main(String[] args) {

	    	String downloadPath = System.getProperty("user.dir") + "/../../../Downloads/Ad-Hoc Report.xls.csv";	
	        String line = "";
	        String cvsSplitBy = ",";
	        List<HashMap<String, String>> List2 = new ArrayList<HashMap<String, String>>();
	        try (BufferedReader br = new BufferedReader(new FileReader(downloadPath))) {
	        	int count = 0;
	        	String[] Header = null;
	            while ((line = br.readLine()) != null) 
	            {
	            	HashMap<String, String> Dict = new HashMap<String, String>(); 
	            	line=line.replace(",\0,", ",,");
//	            	if (line.replace(",", "").equals(null) || line.replace(",", "").equals("")) {
//	            	    System.out.println(line.replace(",", ""));
//	            	    break;
//	            	}
	                //use comma as separator
	                String[] dataRow = line.split(cvsSplitBy);
                    if (count == 0) {
	                	Header = dataRow;
	                }
	                //System.out.println(dataRow.length);
	                for (int i=0; i<dataRow.length; i++) 
	                {
		              
	                 	if(count == 0){
		                 		continue;
	                 	} 
	                 	 	
	                 	Dict.put(Header[i], dataRow[i]);
		                 	//if (count == 5){ break; }                    
		             }
		            // System.out.println("The Dict values are "+Dict);
		             List2.add(Dict);
		            // System.out.println("The List values are "+List2);
		             count=count+1;
	            }
	            
	            
	        } catch (IOException e) {
	            e.printStackTrace();
	        }

	      System.out.println("The Final List is : "+List2);
         
	        for (HashMap<String, String> hm :List2){
	        	try {
	        		//System.out.println("list is :"+hm);
	        	String app_id = hm.get("application_id");
	        	//System.out.println("app id is :"+app_id);
	        		if (app_id.equalsIgnoreCase("19471")) {
	        			String result = hm.get("application_acronym");
	        			System.out.println("The Resultant Value is : "+result);
	        			break;
	        		}
	        	} catch (Exception e) {
	        		continue;
	    		}
		    }	    

	    }
	
// end of class
}

