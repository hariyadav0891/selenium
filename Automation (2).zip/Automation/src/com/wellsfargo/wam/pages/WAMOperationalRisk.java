package com.wellsfargo.wam.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAMOperationalRisk extends BaseTestCase{

	public static final Logger log=Logger.getLogger(WAMOperationalRisk.class.getName());

	

	public WAMOperationalRisk(){			
		PageFactory.initElements(driver, this);
	
	}
	
	//===================Data Extraction and Transmission===
	//Does the application allow data extractions?
	@FindBy(id="allow_extracts")
	public WebElement applicationAllowDataExtractions ;
	
	//Does the asset send/receive data to/from a Third Party/Customer?
	@FindBy(id="asset_send_receive_data_value")
	public WebElement  assetSendReceiveData;
	
	@FindBy(xpath="//input[@type='submit' and @value='Save' ]")
	public WebElement clickSaveButton;
	
	
	//==========================Data Classification=========================
		//What is the highest level of data classification within the application?
	@FindBy(id="data_classification_value")
	public WebElement dataClassification;
	
	//Production Data in Non-Production (Lower) Environments
	
	@FindBy(id="data_non_production_enivironment")
	public WebElement nonProductionEnvironments;
	
	//Does the application's risk assessment reflect the presence of the production data in the non-production environment?
	@FindBy(id="security_plan_reflects")
	public WebElement applicationRisk;
	
	
	//============================Risk Assessment==================================
	//Has an Information Security Risk Assessment (ISRA) been completed for the application?
	
	@FindBy(xpath="//select[@id='covered_by_sp']")
	public WebElement securityRiskISRA;
	
	//Information Security Risk Assessment (ISRA) Number:
	@FindBy(xpath="//input[@id='baseline_security_plan']")
	public WebElement ISRANumber;
	
	//Is the Risk Assessment information above accurate?
	@FindBy(id="is_risk_assess_info_accurate")
	public WebElement riskAssessment;
	
	
	//How many unique records are stored and/or transmitted?
	@FindBy(id="unique_customer_value")
	public WebElement uniqueRecords;
	
		public void applicationAllowDataExtractions(String select){
			WebElement appAllowData = applicationAllowDataExtractions; 
			new Select(appAllowData).selectByVisibleText(select);
			log(" 'Does the application allow' Qrestion select as '"+select+"'  ");
			clickSaveButton.click();
			log("Click on Save Button");
		}
	
		public void assetSendDataToThirdParty(String selectQue ){
			WebElement assetsend = assetSendReceiveData;
			new Select(assetsend).selectByVisibleText(selectQue);
			log("Select Question 'Does the asset send/receive data to/from a Third Party/Customer?' and select as '"+selectQue+"' ");
			clickSaveButton.click();
			log("cliked on Save  Button ");
		}
	
		//Which of these methods is in use?
		public void methodUse(String selectMethod){
			driver.findElement(By.xpath("//label[contains(text(),'"+selectMethod+"')]")).click();
			log("clicking on '"+selectMethod+"' check Box");
		}
		//Which of these methods is in use?
		public boolean verifyMethodUse(String vselectMethod){
			try{
			WebElement eselected = driver.findElement(By.xpath("//label[contains(text(),'"+vselectMethod+"')]"));
				boolean selectedval=eselected.isSelected();
				log("All ready  Selected  Question  '"+vselectMethod+"'");
				return selectedval;
			}
				catch(Exception e){
					return false;
				}
		}
		
				
		//==========================Data Classification=========================
				//What is the highest level of data classification within the application?	
				
		public Object highestDataCalssification(String Data_Classification){
			new Select(dataClassification).selectByVisibleText(Data_Classification);
			log("Selecting  Question 'What is the highest level of data classification within the application?' and value is  '"+Data_Classification+"'");
			return Data_Classification;
		}
			
		//Customer Information
		public void customInformation(String  information){
		
			driver.findElement(By.xpath("//label[contains(text(),'"+information+"')]")).click();
			log("Clicking on '"+information+"'");
			
		}
				
		//Production Data in Non-Production (Lower) Environments
		public void  Non_Production_Environments(String selectEnvironment){
		new Select(nonProductionEnvironments).selectByVisibleText(selectEnvironment);
		clickSaveButton.click();
		log("Click on Save button");
		}
		
		//Does the application's risk assessment reflect the presence of the production data in the non-production environment?	
		public void applicationRiskAssessment(String riskAssessment){
			new Select(applicationRisk).selectByVisibleText(riskAssessment);
			clickSaveButton.click();
		}
		
		
		//============================Risk Assessment=============================
		//Has an Information Security Risk Assessment (ISRA) been completed for the application?
		public void informationSecurityRiskAssessment(String selectISRA){
		//WebElement informationISRA = securityRiskISRA;
		new Select(securityRiskISRA).selectByVisibleText(selectISRA);
		log("Select 'Has an Information Security Risk Assessment (ISRA) been completed for the application?' Question '"+selectISRA+"'  ");	
		}
		
		//Is the Risk Assessment information above accurate?
		
		public void riskAssessmantInformation(String risk){
			new Select(riskAssessment).selectByVisibleText(risk);
		}
		
		//How many unique records are stored and/or transmitted?
		public void uniqreRecordsStore(String uniqueRecord){
			new Select(uniqueRecords).selectByVisibleText(uniqueRecord);
		}
}
