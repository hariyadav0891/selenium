package com.wellsfargo.wam.pages;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAMAdHocReportPage extends BaseTestCase {
public static final Logger log=Logger.getLogger(WAMAdHocReportPage.class.getName());

public WAMAdHocReportPage(){
	PageFactory.initElements(driver, this);
}

//===================Page FActory============================

@FindBy(xpath="//select[@id='ddlAppStatus']")
public WebElement appStatus;

@FindBy(xpath="//select[@id='ddlAssetType']")
public WebElement assetType;

@FindBy(xpath="//input[@name='btnRunReport']")
public WebElement clickOnRunButton;
//======================Method==============================

	public void applicationStstus(String status){
		new Select(appStatus).selectByVisibleText(status);
		log("Select  Application Ststus is "+status);
	}
	public void assetType(String type){
		new Select(assetType).selectByVisibleText(type);
		log("Select  Assert Type is "+type);
	}
	
	public void SelectAdHocQuestion(String question){
		driver.findElement(By.xpath("//td[contains(text(),'"+question+"')]/following-sibling::td/input")).click();
		log("Question is salected as "+question);
	}
	// For Validation Ad-Hoc Report with csv file
	public String validateAdhocReport(String appID, String columnHeader)  {
    	String downloadPath = System.getProperty("user.dir") + "/../../../Downloads/Ad-Hoc Report.xls.csv";	
        String adhocRow = "";
        String cvsSplitBy = ",";  
        String result = null;
        List<HashMap<String, String>> adhocList = new ArrayList<HashMap<String, String>>();
	      try (BufferedReader br = new BufferedReader(new FileReader(downloadPath))) 
	       {
	       	int count = 0;
	       	String[] Header = null;
	          while ((adhocRow = br.readLine()) != null) 
	          {
	           	HashMap<String, String> Dict = new HashMap<String, String>(); 
	           	//adhocRow = adhocRow.replace(",\0,", ",,");
	           	adhocRow = adhocRow.replaceAll("\0", "");
	            //use comma as separator
	             String[] dataRow = adhocRow.split(cvsSplitBy);
	             if (count == 0) {
	              	Header = dataRow;
	                }
	                for (int i=0; i<dataRow.length; i++) 
	                {
		              
	                 	if(count == 0){
		                 		continue;
	                 	} 
	                 	 	
	                 	Dict.put(Header[i], dataRow[i]);
		             }
		             adhocList.add(Dict);
		             count=count+1;             
	            }         
	       } catch (IOException e) 
	       {
	        e.printStackTrace();
	       }
//	        System.out.println("The Final List Size is"+adhocList.size());    
       // System.out.println("The Final List is "+adhocList);
	        for (HashMap<String, String> hm :adhocList){
	        	try 
	        	{
	        		String app_id = hm.get("application_id");
	        		if (app_id.equalsIgnoreCase(appID)) 
	        		{
	        			result = hm.get(columnHeader);
	        			System.out.println("Result is : "+result);
	        			break;
	        		}
	        	} catch (Exception e) 
	        	{
	        		continue;
	    		}
		    }
			return result;	    
	    }
		
		public void deleteFile() {
			String downloadPath = System.getProperty("user.dir") + "/../../../Downloads/Ad-Hoc Report.xls.csv";
			try
	        {
				Files.deleteIfExists(Paths.get(downloadPath));
				log("File is Deleted ");
	        }
	        catch(IOException e)
	        {
	            System.out.println("No such file/directory exists");
	        }	
		}	
		
	// end of class	
	
}
