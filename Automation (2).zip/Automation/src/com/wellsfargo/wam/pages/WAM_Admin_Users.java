package com.wellsfargo.wam.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAM_Admin_Users extends BaseTestCase{

	public static final Logger log=Logger.getLogger(WAMOperationalRisk.class.getName());

	public WAM_Admin_Users(){
		PageFactory.initElements(driver,this);
	}

	
	//==============Page Factory==========================
	
	//search by LAn ID
	@FindBy(xpath="//input[@id='gs_lan_id']")
	public WebElement lanID;
	
	
	//click on Edit Link
	@FindBy(xpath="//a[contains(text(),'Edit')]")
	public WebElement clickOnEditLink;
	
	//Global Administrator
	@FindBy(xpath="//input[@id='global_admin']")
	public WebElement gAdministrator;
	
	
	// click on Save Button
	@FindBy(xpath="//input[@value='Save']")
	public WebElement clickONSave;
	
	//Update App Roles
	@FindBy(xpath="//a[contains(text(),'Update App Roles')]")
	public WebElement appRole;
	
	//	Add New Application
	@FindBy(xpath="//div[contains(text(),'Add New Application')]")
	public WebElement addNewApp;
		
		// Search By
	@FindBy(xpath="//select[@id='tr_UATadd_criteria']")
	public WebElement searchby;
	
		//Application ID
		
	@FindBy(xpath="//input[@id='UATadd_application_id']")
	public WebElement appIDD;
		
	// search Button
	@FindBy(xpath="//input[@id='UATadd_searchBtn']")
	public WebElement searchButton;
	
	//click on save Button
	@FindBy(xpath="//a[@id='sData']")
	public WebElement clickOnSaveButton;
	
	
		
	// =========================page Method==============================
	

	//search by LAn ID
	public void searchForLanID(String lanid){
		lanID.sendKeys(lanid);
		log(" Search By Lan Id and  lan id is:-'"+lanid+"' ");
		lanID.sendKeys(Keys.ENTER);
		
	}
	//Global Administrator:
	public boolean globalAdminstrator(){
		
		try{
			gAdministrator.isSelected();
			log("Global Administrator Roles is already given to User ");
			return true;
		} catch( Exception e){
			return false;
			
		}
		
	}
	
	//Update App Roles
	public void updateAppRole(){
		appRole.click();
		log("Clicking On Update App Roles");
		addNewApp.click();
		log("Clicking On Add New Application ");
	}
	//search by App iD
	public void seaechBYAPPId(){
		new Select(searchby).selectByVisibleText("Application ID");
		log("Selecting by Application ID");
		
	}
	//selecting Roles
	public void editRoles(String role){
		driver.findElement(By.xpath("//td[contains(text(),'"+role+"')]/ancestor::tr/td[2]/input")).click();
		log("Select roles:- "+role+" for application "+role.toString());
		
	}
	
	public boolean VelidateAppID(String appID){
		try{
		driver.findElement(By.xpath("//td[contains(text(),'"+appID+"')]")).isDisplayed();
		return true;
		}
		catch(Exception e){
			return false;
			
		}
	}
	//edit App role
	public void editAppRoles(String appName){
		driver.findElement(By.xpath("//td[contains(text(),'"+appName+"')]/following-sibling::td[18]/div[1]/div[1]/span")).click();
		log(" App for Edit  roles:- "+appName+" for application ");
		
	}
}
