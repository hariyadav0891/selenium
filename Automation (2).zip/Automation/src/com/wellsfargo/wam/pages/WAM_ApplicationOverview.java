package com.wellsfargo.wam.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAM_ApplicationOverview extends BaseTestCase {

	public static final Logger log=Logger.getLogger(WAMOperationalRisk.class.getName());
	public WAM_ApplicationOverview(){
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//button[@id='MyAppsbutton']")
	public WebElement clickMyApp;
	
	@FindBy(id="gs_asset_type")
	public WebElement selectAssetType;
	
	@FindBy(id="gs_application_name")
	public  WebElement searchByName;
	
	@FindBy(xpath="//a[contains(text(),'Input')]")
	public WebElement clickOnInput;
	@FindBy(xpath="//button[@id='details']")
	public WebElement clickOnValidateButton;
	
	//Is above owning application accurate?

	@FindBy(xpath="//select[@id='OwningApp_accurate']")
	public WebElement owningApplication;
	
	//Is there a Website?
	@FindBy(xpath="//select[@id='is_there_website']")
	public WebElement website;
	
	//Does this application use Tealeaf to capture session data?

	@FindBy(xpath="//select[@id='use_tealeaf_session']")
	public WebElement captureSession;

	
	public void searchForApp1(String name){
		clickMyApp.click();
		log("cliked on All App Button and object is:-"+clickMyApp.toString());
		//waitforElement(1, clickMyApp );
		
		WebElement selectAsset=selectAssetType;
		new Select(selectAsset).selectByVisibleText("Application Subsystem");
	
		log("Select by Asset Type and object is:-"+selectAssetType.toString());
		//searchByName("WHOLESALE AUTHENTICATION SERVICES", oWAMLoginmyapp.searchByName);
		searchByName.sendKeys(name);
		log("Searching by "+name+" and object is:-"+searchByName.toString());
		//waitforElement(1, searchByName );
		searchByName.sendKeys(Keys.ENTER);
		clickOnInput.click();
		log("cliked on Input Button and object is:-"+clickOnInput.toString());
		
	}
	public void clickOnNavigationMenu1(String menuName){
		driver.findElement(By.xpath("//a[contains(text(),'"+menuName+"')]")).click();
		log("clicked on:-"+menuName+" navigation menu");
		
	}
	public boolean verifyValidationOnValidationPage(String Question){
		try {
			driver.findElement(By.xpath("//td[contains(text(),'"+Question+"')]")).isDisplayed();
			log("Validation Question Is'"+Question+"' Dispayed in Validation Page and object is:-"+Question.toString());
			return true;
		} catch (Exception e) {
			return false;
		}
	}
	
	
	public void owningApplicationAccurate(String selectQuestion){
		WebElement AppSelect = owningApplication;
		new Select(AppSelect).selectByVisibleText(selectQuestion);
	}
	
	//Is there a Website?
	public void thereAWebSite(String selectWebSite){
		WebElement websiteSelect = website;
		new Select(websiteSelect).selectByVisibleText(selectWebSite);
		
	}
	//Does this application use Tealeaf to capture session data?
	public void TealeafToCaptureSession(String selectSession){
		WebElement captureSelect = captureSession;
		new Select(captureSelect).selectByVisibleText(selectSession);
		
	}
}
