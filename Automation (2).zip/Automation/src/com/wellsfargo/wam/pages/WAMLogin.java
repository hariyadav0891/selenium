package com.wellsfargo.wam.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.wellsfargo.wam.common.BaseTestCase;

public class WAMLogin extends BaseTestCase{		


	public WAMLogin(){			
		PageFactory.initElements(driver, this);
	
	}
	
	@FindBy(xpath="//*[contains(@src,'Close_On_Red.png')]")
	public WebElement buttonClose;	
	
	@FindBy(id="MyAppsbutton")
	public WebElement buttonAllApps;
	
	@FindBy(id="gs_application_name")
	public WebElement searchNameField;
	
	@FindBy(xpath="//a[contains(text(), 'Input')]")
	public WebElement linkInput;
	
	@FindBy(id="tech")
	public WebElement buttonTechnicalInput;
	
	@FindBy(xpath="//h2[contains(text(), 'Technical Application Overview')]")
	public WebElement textTechnicalApplicationOverview;
	
}
