package com.wellsfargo.wam.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAM_TechnicalApplicationOverview extends BaseTestCase{


	public WAM_TechnicalApplicationOverview(){
		PageFactory.initElements(driver, this);
	}
	
	//============================== Start Page Factory============================
	
	// Application Production Website URL 
	@FindBy(xpath="//textarea[@id='app_production_website_URL']")
	public WebElement websitURL;
	

	//============================== End Page Factory============================
	
	
	//==========================Methods =======================================
	
	//Is there a Website? sub Question 
	public void websitSubQue(String selectque){
		driver.findElement(By.xpath("//label[contains(text(),'"+selectque+"')]")).click();
		log("Question 'Is there a Website?' select Sub Question'Internet/Intranet'  as'"+selectque+"' ");
		
	}
	
	//common method for select by select option 
	public void comnmethodSelect(String comnQuestion ,String SelectOption){
		WebElement comnEle = driver.findElement(By.xpath("//td[contains(text(),'"+comnQuestion+"')]/following-sibling::td/select"));
		new Select(comnEle).selectByVisibleText(SelectOption);
		log("Question '"+comnQuestion+"'  and Option is '"+SelectOption+"' ");
	}
	
	//==========================End Methods =======================================
}
