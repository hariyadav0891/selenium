package com.wellsfargo.wam.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAM_SDLC extends BaseTestCase {
	public static final Logger log=Logger.getLogger(WAMOperationalRisk.class.getName());

	public WAM_SDLC(){
		PageFactory.initElements(driver, this);
	}
	//Have test and production environments been established with proper permission levels?
	
	//==============================page Factory========================
	@FindBy(xpath="//select[@id='environment_permission_level']")
	public WebElement permissionLevels;
	
	//save button
	@FindBy(xpath="//input[@type='submit' and @value='Save']")
	public WebElement clickOnSaveButton;
	
	//Has the application been added to SD Elements?
	@FindBy(xpath="//select[@id='sd_element']")
	public WebElement SDElements;
	
	//Software type
	@FindBy(xpath="//select[@id='sdlc_sfotware_type']")
	public WebElement softwaretype;
	


	////Is all code built/compiled in a development/build environment?
	@FindBy(xpath="//select[@id='control_env_code_build']")
	public WebElement buildEnvironment;
	
//=================================method=================================
	
	//Have test and production environments been established with proper permission levels?
	public void established_With_Permission(String permissionSelect){
		new Select(permissionLevels).selectByVisibleText(permissionSelect);
		log("Question 'Have test and production environments been established with proper permission levels?' select as'"+permissionSelect+"' ");
		
	}
	
	//click on save button 
	public void clickSaveButton(){
		clickOnSaveButton.click();
		log("click on save Button");
	}
	
	//Has the application been added to SD Elements?
	public void addToSDElement(String sdElement){
		new Select(SDElements).selectByVisibleText(sdElement);
		log("Question 'Has the application been added to SD Elements?' select as'"+sdElement+"' ");
		
	}
	//Software type
	public void softwareType(String softwaewSelect){
		new Select(softwaretype).selectByVisibleText(softwaewSelect);
		log("Question 'Software type' select as'"+softwaewSelect+"' ");
		
		
	}
	//Indicate where the code/software is installed/running? (select all that apply)
	
	public void software_Installed_Running(String indicateItem ){
		waitforElement(3, softwaretype);
		driver.findElement(By.xpath("//label[contains(text(),'"+indicateItem+"')]")).click();
		log("Select on:-"+indicateItem+" from software is installed/running?");
	}
		
	////Roles & Responsibilities:-	Select the roles involved in building and deploying the code
	
	public void Roles_Responsibilities(String selectRoles ){
		driver.findElement(By.xpath("//label[contains(text(),'"+selectRoles+"')]")).click();
		log("Select on:-"+selectRoles+" from Roles & Responsibilities");
	}
	//Is all code built/compiled in a development/build environment?
	public void buildEnvironment(String selectbuild ){
		new Select(buildEnvironment).selectByVisibleText(selectbuild);
		log("Select on:-"+selectbuild+" from built/compiled in a development/build environment");
	}
}
