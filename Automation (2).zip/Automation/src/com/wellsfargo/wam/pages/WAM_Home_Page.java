package com.wellsfargo.wam.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAM_Home_Page extends BaseTestCase{

	public static final Logger log=Logger.getLogger(WAMOperationalRisk.class.getName());
	
	public WAM_Home_Page(){
		PageFactory.initElements(driver, this);
	}

	//========================Start Page factory=====================
	@FindBy(xpath="//button[@id='MyAppsbutton']")
	public WebElement clickMyApp;
	
	@FindBy(id="gs_asset_type")
	public WebElement selectAssetType;
	
	@FindBy(id="gs_application_name")
	public  WebElement searchByName;
	
	@FindBy(xpath="//a[contains(text(),'Input')]")
	public WebElement clickOnInput;
	
	@FindBy(xpath="//input[@type='submit' and @value='Save' ]")
	public WebElement clickSaveButton;

	
	@FindBy(xpath="//button[@id='details']")
	public WebElement clickOnValidateButton;
	
	
	@FindBy(xpath="//td[contains(text(),'Technical Input')]/preceding-sibling::td/input")
	public WebElement technicalInputRadioButton;
	
	@FindBy(xpath="//span[contains(text(),'Ad-hoc Report')]")
	public WebElement adhocReport;
	//========================End Page factory=====================
	
	
	
	//=======================================Start common methods===============
	
	public void searchForApp(String name ,String Application_Type ){
	clickMyApp.click();
	log("cliked on All App Button  and search app nae '"+name+"'");
		//waitforElement(1, clickMyApp );
	WebElement selectAsset=selectAssetType;
	new Select(selectAsset).selectByVisibleText(Application_Type);
	log("Select by Asset Type and select assert '"+Application_Type+"' ");
		//searchByName("WHOLESALE AUTHENTICATION SERVICES", oWAMLoginmyapp.searchByName);
	searchByName.sendKeys(name);
	log("Searching by "+name+" ");
		//waitforElement(1, searchByName );
	searchByName.sendKeys(Keys.ENTER);
	clickOnInput.click();
	log("cliked on Application  Input Button ");
	if(Application_Type=="Application" || Application_Type=="Platform Service" ||  Application_Type  =="Software"){
		technicalInputRadioButton.click();
		log("cliked on Technical Input Button ");
		}
	}
	public void clickOnNavigationMenu(String menuName){
	driver.findElement(By.xpath("//a[contains(text(),'"+menuName+"')]")).click();
	log("clicked on:-"+menuName+" navigation menu");
	}
	
	public boolean verifyValidationOnValidationPage(String Question){
	try {
		driver.findElement(By.xpath("//td[contains(text(),'"+Question+"')]")).isDisplayed();
		log("Validation Question Is'"+Question+"' Dispayed in Validation Page ");
		log("Validation Successfull ...");
				return true;
	} catch (Exception e) {
			return false;	
		}
	}
	public void clickOnValidationLink(String ValidationQuestion){
	driver.findElement(By.xpath("//td[contains(text(),'"+ValidationQuestion+"')]/following-sibling::td/a")).click();
	log("clicking on  Question 'Which of these methods is in use?' and value is  '"+ValidationQuestion+"'");
	}
	
	
	//==========================validation page view report=========================
	public String  viewPagevalidationOfQuestion(String question){
		try{
			String question_val = driver.findElement(By.xpath("//td[contains(text(),'"+question+"')]/following-sibling::td")).getText();
			log("Varify   Question '"+question+" ' on View  Page Validation");
			return question_val;
		} catch(Exception e){
			return null;			
		}
	}
	
	// check box is Selected
	public  void checkBooxISSelected(String deploymentsItem ){
		try{
		WebElement findElement = driver.findElement(By.xpath("//label[contains(text(),'"+deploymentsItem+"')]/preceding-sibling::input[1]"));
			if(!(findElement.isSelected())){
				findElement.click();
				log("Check Box '"+deploymentsItem+"' checked ");
			}else{
				log("Check Box '"+deploymentsItem+"' checked all ready  ");
			}
		
		} catch(Exception e){
			
		}
		
	}
	//=======================================End common methods===============

}
