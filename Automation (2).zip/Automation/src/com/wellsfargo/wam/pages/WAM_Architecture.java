package com.wellsfargo.wam.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.wellsfargo.wam.common.BaseTestCase;

public class WAM_Architecture extends BaseTestCase {

public WAM_Architecture(){
	PageFactory.initElements(driver, this);
}
//==============================Start page Factory========================
//Application Specification:-Application Category
@FindBy(id="app_category")
public WebElement application_category;

//Does this application feed from or rely on batch jobs?
@FindBy(id="rely_batch_jobs")
public WebElement app_batch_job;

//Architecture Model
@FindBy(id="architect_model")
public WebElement ArcModel;

//Are the application architectural artifacts housed in Wholesale Architectural Library (WAL)?
@FindBy(id="artifacts_WAL")
public WebElement ArcArtifacts;

//Does the application have a Roadmap?
@FindBy(id="application_roadmap")
public WebElement appRoadmap;

//Provide the link where roadmap information is stored
@FindBy(id="application_roadmaplink")
public WebElement roadMapInfo;

//Network Environments
@FindBy(id="network")
public WebElement networkEnv;
//==============================End page Factory==============================

//=================================start method=================================

//Application Specification:-Application Category
public void app_category(String appOption){
	new Select(application_category).selectByVisibleText(appOption);
	log("Application Category is : '"+appOption);
}

//Does this application feed from or rely on batch jobs?
public void application_batch_job(String appBatch){
	new Select(app_batch_job).selectByVisibleText(appBatch);
	log("'Does this application feed from or rely on batch jobs?' is '"+appBatch);
}
//Architecture Model
public void architectureModel(String Arcmodel){
	new Select(ArcModel).selectByVisibleText(Arcmodel);
	log("Architecture Model is : '"+Arcmodel);
}
//Are the application architectural artifacts housed in Wholesale Architectural Library (WAL)?
public void architectureartifacts(String artifact){
	new Select(ArcArtifacts).selectByVisibleText(artifact);
	log("'Are the application architectural artifacts housed in Wholesale Architectural Library (WAL)?' is : '"+artifact);
}
//Does the application have a Roadmap?
public void applicationRoadmapl(String rmap){
	new Select(appRoadmap).selectByVisibleText(rmap);
	log(" 'Does the application have a Roadmap?' is : '"+rmap);
}
//Network Environments
public void NetWorkEnvironments(String newwork){
	new Select(networkEnv).selectByVisibleText(newwork);
	log("Network Environments is : '"+newwork);
}

//=================================End method===================================
}
