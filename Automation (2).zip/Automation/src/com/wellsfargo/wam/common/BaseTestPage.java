package com.wellsfargo.wam.common;

public class BaseTestPage {

}
