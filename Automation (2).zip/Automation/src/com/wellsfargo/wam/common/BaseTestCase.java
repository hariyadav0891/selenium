package com.wellsfargo.wam.common;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class BaseTestCase {

	public static final Logger log=Logger.getLogger(BaseTestCase.class.getName());
	
	public static WebDriver driver;
	public static ExtentReports extend;
	public static File file ;
	public static Properties OR;
	public static ExtentTest logger;
	public static ExtentReports extent;

	
	static {
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		extent = new ExtentReports(System.getProperty("user.dir") + "/src/com/wellsfargo/wam/report/test" + formater.format(calendar.getTime()) + ".html", false);
	}
	
	
	public void init() throws IOException {
		loadData();
		// lis= new Listener();
		String log4jConfPath = "log4j.properties";
		PropertyConfigurator.configure(log4jConfPath);
		//System.out.println(OR.getProperty("browser"));
		selectBrowser(OR.getProperty("browser"));
		getUrl(OR.getProperty("url"));
	}
	
	public void getUrl(String url) {
		log.info("navigating to :-" + url);
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	
	@SuppressWarnings("deprecation")
	public void selectBrowser(String browser){
		if(browser.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/chromedriver.exe");
			driver = new ChromeDriver();

		}else if(browser.equals("fireFox")){
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/geckodriver.exe");
			driver = new FirefoxDriver();
		}else if(browser.equals("ie")){
			System.setProperty("webdriver.ie.driver", System.getProperty("user.dir") + "/IEDriverServer.exe");
			DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
			capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
			driver = new InternetExplorerDriver(capabilities);
		}
	}
	
	public void loadData() throws IOException{
		file = new File(System.getProperty("user.dir")+"/src/com/wellsfargo/wam/config/config.properties");
		FileInputStream fi= new FileInputStream(file);
		 OR= new Properties();
		 OR.load(fi);
		
	}
	
	static public void sendkeys(String data, WebElement element) {
		
		JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
		myExecutor.executeScript("arguments[0].value='"+data+"';", element);     
	}
	
	
	@SuppressWarnings("unused")
	static public String readExcel(String SheetName, String key) throws BiffException, IOException {
					 
		String FilePath = "src/com/wellsfargo/wam/resources/wamdata.xls"; 
		String value ="";
		FileInputStream fs = new FileInputStream(FilePath);
		Workbook wb = Workbook.getWorkbook(fs);
		
		Sheet sh = wb.getSheet(SheetName);
		int totalNoOfRows = sh.getRows();
		int totalNoOfCols = sh.getColumns();

		Loop1 : for (int row = 0; row < totalNoOfRows; row++) {
			Loop2 : for (int col = 0; col < totalNoOfCols; col++) {
				
				if(key.equalsIgnoreCase(sh.getCell(col, row).getContents())) {
					value = sh.getCell(col+1, row).getContents();
					break Loop1;
				}
			}		
		}
		return value;
	}	
	
	static public WAMData getWAMdata(int projectId) throws BiffException, Exception {
		
		Connection con = null;
		ResultSet result = null;
		PreparedStatement pst = null;
		WAMData oWAMData = null;
		
		try{
				Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		}
		catch(ClassNotFoundException cnf)
		{
			System.out.println("Driver class Not Found in path :"+cnf.getMessage());
		}
		
		try
		{
		
		String msAccDB = "C:\\Users\\u345722.AD-ENT\\Documents\\Database3.accdb";
		String dbURL = "jdbc:ucanaccess://" + msAccDB; 

			//String fileURI ="C:\\Users\\u345722.AD-ENT\\Documents\\Database1.accdb";
			//con = DriverManager.getConnection("jdbc:odbc:;Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + fileURI);
			con = DriverManager.getConnection(dbURL); 


			pst = con.prepareStatement("select * from Emp where projectId=? ");
			pst.setInt(1, projectId);			
			result = pst.executeQuery();
			oWAMData = new WAMData();
			while(result.next())
			{
				oWAMData.setName(result.getString("Name"));
				oWAMData.setCity(result.getString("City"));			
					
			}			
			
		}
		catch(SQLException sqe)
		{
			System.out.println("SQL Exception Occurs :"+sqe.getMessage());
		}
		finally{
			
			if(pst!=null)
			{
				pst.close();
			}
			
		}
		
			return oWAMData;		
			
	}
 
	public static WebElement waitforElement( long time,WebElement element) {
		WebDriverWait wait = new WebDriverWait(driver, time);
		return wait.until(ExpectedConditions.elementToBeClickable(element));

	}
		/*
		 public void getScreenShot(String name){

		Calendar calendar= Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

		try{
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/com/wellsFargo/wam/screenshot/";
			File destFile = new File((String) reportDirectory + name + "_" + formater.format(calendar.getTime()) + ".png");
			FileUtils.copyFile(scrFile, destFile);
			// This will help us to link the screen shot in testNG report
			Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath() + "' height='100' width='100'/> </a>");
			
		}catch(IOException e){
			e.printStackTrace();
		}
			
	}
	*/
	
	
	public void log(String data) {
		log.info(data);
		//Reporter.log(data);
		logger.log(LogStatus.INFO, data);
	}


	public String captureScreen(String fileName) {
		if (fileName == "") {
			fileName = "blank";
		}
		File destFile = null;
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/com/wellsFargo/wam/screenshot/";
			destFile = new File((String) reportDirectory + fileName + "_" + formater.format(calendar.getTime()) + ".png");
			FileUtils.copyFile(scrFile, destFile);
			// This will help us to link the screen shot in testNG report
			Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath() + "' height='100' width='100'/> </a>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return destFile.toString();
	}

	
	public void getresult(ITestResult result){
		if(result.getStatus()==ITestResult.SUCCESS){
			logger.log(LogStatus.PASS, result.getName() + " test is pass");
		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.log(LogStatus.SKIP, result.getName() + " test is skipped and skip reason is:-" + result.getThrowable());
		} else if (result.getStatus() == ITestResult.FAILURE) {
			logger.log(LogStatus.ERROR, result.getName() + " test is failed" + result.getThrowable());
			String screen = captureScreen("Extend_report");
			logger.log(LogStatus.FAIL, logger.addScreenCapture(screen));
		} else if (result.getStatus() == ITestResult.STARTED) {
			logger.log(LogStatus.INFO, result.getName() + " test is started");
		}
		
	}
	
	@AfterMethod()
	public void afterMethod(ITestResult result) {
		getresult(result);
	}

	
	@BeforeMethod()
	public void beforeMethod(Method result) throws IOException {
		//getresult(result);
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/com/wellsFargo/wam/report/";
		
		extent = new ExtentReports ((String) reportDirectory +  "TEST_" + formater.format(calendar.getTime()) + ".html", true);
		extent
                .addSystemInfo("Environment", "Automation Testing")
                .addSystemInfo("User Name", "Hari shanker ");
                extent.loadConfig(new File(System.getProperty("user.dir")+"/extent-config.xml"));
		logger = extent.startTest(result.getName());
		logger.log(LogStatus.INFO, result.getName() + " test Started");
		//init();
	}

	@AfterClass(alwaysRun = true)
	public void endTest() {
		closeBrowser();
	}

	public void closeBrowser() {
		driver.quit();
		log.info("browser closed");
		extent.endTest(logger);
		extent.flush();
	}
	
	public Iterator<String> getAllWindow(){
		Set<String> windows = driver.getWindowHandles();
		Iterator<String> itr = windows.iterator();
		return itr;
		
	}
	//=============================================
	/*
	public void clickOnNavigationMenu(String menuName){
		driver.findElement(By.xpath("//a[contains(text(),'"+menuName+"')]")).click();
		log("clicked on:-"+menuName+" navigation menu");
		}
		
		public boolean verifyValidationOnValidationPage(String Question){
		try {
			driver.findElement(By.xpath("//td[contains(text(),'"+Question+"')]")).isDisplayed();
			log("Validation Question Is'"+Question+"' Dispayed in Validation Page ");
			log("Validation Successfull ...");
					return true;
		} catch (Exception e) {
				return false;	
			}
		}
		public void clickOnValidationLink(String ValidationQuestion){
		driver.findElement(By.xpath("//td[contains(text(),'"+ValidationQuestion+"')]/following-sibling::td/a")).click();
		log("clicking on  Question 'Which of these methods is in use?' and value is  '"+ValidationQuestion+"'");
		}
		
		
		//==========================validation page view report=========================
		public String  viewPagevalidationOfQuestion(String question){
			try{
				String question_val = driver.findElement(By.xpath("//td[contains(text(),'"+question+"')]/following-sibling::td")).getText();
				log("Varify   Question '"+question+" ' on View  Page Validation");
				return question_val;
			} catch(Exception e){
				return null;			
			}
		}
		
		// check box is Selected
		public  void checkBooxISSelected(String deploymentsItem ){
			try{
			WebElement findElement = driver.findElement(By.xpath("//label[contains(text(),'"+deploymentsItem+"')]/preceding-sibling::input[1]"));
				if(!(findElement.isSelected())){
					findElement.click();
					log("Check Box '"+deploymentsItem+"' checked ");
				}else{
					log("Check Box '"+deploymentsItem+"' checked all ready  ");
				}
			
			} catch(Exception e){
				
			}
			
		}
		//=======================================End common methods===============
	*/
	
}// end of class
